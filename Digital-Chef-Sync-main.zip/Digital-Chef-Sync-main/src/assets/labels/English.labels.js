const labels = {
  hello: 'Hello',
  SignIn: 'SignIn',
  home: 'Home',
  forgotPin: 'Forgot pin? ',
  reset: 'reset',
  emailAddress: 'Email address',
  SignInPin: 'SignIn pin',
  dontHaveAnAccount: 'Don’t have an account?',
  signUp: 'Sign up',
};
export default labels;
