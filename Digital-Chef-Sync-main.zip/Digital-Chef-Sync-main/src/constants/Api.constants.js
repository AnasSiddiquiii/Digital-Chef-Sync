const api = {
  baseUrl: 'http://baseurl.com',
};

export default api;
