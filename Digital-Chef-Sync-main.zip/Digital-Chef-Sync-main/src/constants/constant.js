import {images} from '../config/Images';

export const salaryData = [
  {label: '£100 to £150', value: '100'},
  {label: '£200 to £250', value: '200'},
  {label: '£300 to £350', value: '300'},
  {label: '£400 to £450', value: '400'},
  {label: '£500 to £550', value: '500'},
  {label: '£600 to £650', value: '600'},
  {label: '£700 to £750', value: '700'},
  {label: '£800 to £850', value: '800'},
];
export const venues = [
  {label: 'UK Branch', value: 'UK'},
  {label: 'USA Branch', value: 'USA'},
  {label: 'UAE Branch', value: 'UAE'},
];

export const data = [
  {label: 'No break', value: 'No break'},
  {label: '10 minute', value: '10 minute'},
  {label: '20 minute', value: '20 minute'},
  {label: '30 minute', value: '30 minute'},
  {label: '40 minute', value: '40 minute'},
  {label: '50 minute', value: '50 minute'},
  {label: 'Strawberry', value: 'strawberry'},
  {label: 'Blueberry', value: 'blueberry'},
  {label: 'Watermelon', value: 'watermelon'},
  {label: 'Peach', value: 'peach'},
  {label: 'Kiwi', value: 'kiwi'},
  {label: 'Papaya', value: 'papaya'},
  {label: 'Lemon', value: 'lemon'},
  {label: 'Lime', value: 'lime'},
  {label: 'Cherry', value: 'cherry'},
  {label: 'Plum', value: 'plum'},
  {label: 'Apricot', value: 'apricot'},
  {label: 'Pomegranate', value: 'pomegranate'},
  {label: 'Coconut', value: 'coconut'},
  {label: 'Avocado', value: 'avocado'},
];

export const shifts = [
  '30-06-2025  11:00-23:00',
  '01-07-2025  11:00-23:00',
  '02-07-2025  11:00-23:00',
  '03-07-2025  11:00-23:00',
  '04-07-2025  11:00-23:00',
  '05-07-2025  11:00-23:00',
  '06-07-2025  11:00-23:00',
  '07-07-2025  11:00-23:00',
  '09-07-2025  11:00-23:00',
  '10-07-2025  11:00-23:00',
  '11-07-2025  11:00-23:00',
  '12-07-2025  11:00-23:00',
  '13-07-2025  11:00-23:00 ',
];
export const benefits = [
  'Job security: Tech jobs are considered to be relatively secure. ',
  'Competitive salaries: Tech salaries are among the highest in the job market.',
  'Tech jobs often include performance bonuses, stock options, and other benefits.',
];

export const roles = [
  'Sous Chef',
  'Pastry Chef',
  'Commis Chef',
  'Chef de Partie',
  'Executive Chef',
  'Head Chef',
  'Line Cook',
  'Prep Cook',
  'Grill Chef',
  'Saucier',
];

export const qualifications = [
  'Culinary Arts Degree',
  'Food Safety Certification',
  'Advanced Knife Skills',
  'Menu Planning and Development',
  'Experience in High-Volume Kitchens',
];
export const behaviours = [
  'Teamwork',
  'Attention to Detail',
  'Time Management',
  'Adaptability',
  'Problem Solving',
];

export const jobDataDemo = [
  {
    date: '30-06-2025 - 14 shifts',
    title: 'Hotel Manager',
    subTitle: 'Pearl Continental Lahore',
    location: 'Lahore, Pakistan',
    postalCode: '54000',
    jobType: 'Full-time',
    timeAgo: '3 w ago',
    salary: 'Rs. 150,000',
    hour: '/month',
    image: images.businessImg,
    type: 'Permanent',
    status: 'active',
  },
  {
    date: '05-07-2025 - 10 shifts',
    title: 'Waiter',
    subTitle: 'Serena Hotel',
    location: 'Islamabad, Pakistan',
    postalCode: '44000',
    jobType: 'Part-time',
    timeAgo: '2 w ago',
    salary: 'Rs. 25,000',
    hour: '/month',
    image: images.businessImg,
    type: 'Temporary',
    status: 'pending',
  },
  {
    date: '12-07-2025 - 8 shifts',
    title: 'Sous Chef',
    subTitle: 'Marriott Hotel',
    location: 'Karachi, Pakistan',
    postalCode: '75000',
    jobType: 'Full-time',
    timeAgo: '1 w ago',
    salary: 'Rs. 90,000',
    hour: '/month',
    image: images.businessImg,
    type: 'Permanent',
    status: 'active',
  },
  {
    date: '20-07-2025 - 6 shifts',
    title: 'Tandoori Chef',
    subTitle: 'Nishat Hotel',
    location: 'Lahore, Pakistan',
    postalCode: '54000',
    jobType: 'Temporary',
    timeAgo: '5 d ago',
    salary: 'Rs. 60,000',
    hour: '/month',
    image: images.businessImg,
    type: 'Temporary',
    status: 'complete',
  },
  {
    date: '28-07-2025 - 9 shifts',
    title: 'Cashier',
    subTitle: 'Salt Bae Grill',
    location: 'Faisalabad, Pakistan',
    postalCode: '38000',
    jobType: 'Part-time',
    timeAgo: '2 d ago',
    salary: 'Rs. 30,000',
    hour: '/month',
    image: images.businessImg,
    type: 'Temporary',
    status: 'active',
  },
  {
    date: '01-08-2025 - 5 shifts',
    title: 'Pastry Chef',
    subTitle: 'Marriott Bakery Lounge',
    location: 'Islamabad, Pakistan',
    postalCode: '44000',
    jobType: 'Temporary',
    timeAgo: '1 d ago',
    salary: 'Rs. 55,000',
    hour: '/month',
    image: images.businessImg,
    type: 'Temporary',
    status: 'pending',
  },
];
export const jobDataDemoSeeker = [
  {
    date: '30-06-2025 - 14 shifts',
    title: 'Hotel Manager',
    subTitle: 'Pearl Continental Lahore',
    location: 'Lahore, Pakistan',
    postalCode: '54000',
    jobType: 'Full-time',
    timeAgo: '3 w ago',
    salary: 'Rs. 150,000',
    hour: '/month',
    image: images.businessImg,
    type: 'Permanent',
    status: 'active',
  },
  {
    date: '05-07-2025 - 10 shifts',
    title: 'Waiter',
    subTitle: 'Serena Hotel',
    location: 'Islamabad, Pakistan',
    postalCode: '44000',
    jobType: 'Part-time',
    timeAgo: '2 w ago',
    salary: 'Rs. 25,000',
    hour: '/month',
    image: images.businessImg2,
    type: 'Temporary',
    status: 'pending',
  },
  {
    date: '12-07-2025 - 8 shifts',
    title: 'Sous Chef',
    subTitle: 'Marriott Hotel',
    location: 'Karachi, Pakistan',
    postalCode: '75000',
    jobType: 'Full-time',
    timeAgo: '1 w ago',
    salary: 'Rs. 90,000',
    hour: '/month',
    image: images.businessImg3,
    type: 'Permanent',
    status: 'active',
  },
  {
    date: '20-07-2025 - 6 shifts',
    title: 'Tandoori Chef',
    subTitle: 'Nishat Hotel',
    location: 'Lahore, Pakistan',
    postalCode: '54000',
    jobType: 'Temporary',
    timeAgo: '5 d ago',
    salary: 'Rs. 60,000',
    hour: '/month',
    image: images.businessImg4,
    type: 'Temporary',
    status: 'complete',
  },
  {
    date: '28-07-2025 - 9 shifts',
    title: 'Cashier',
    subTitle: 'Salt Bae Grill',
    location: 'Faisalabad, Pakistan',
    postalCode: '38000',
    jobType: 'Part-time',
    timeAgo: '2 d ago',
    salary: 'Rs. 30,000',
    hour: '/month',
    image: images.businessImg5,
    type: 'Temporary',
    status: 'active',
  },
  {
    date: '01-08-2025 - 5 shifts',
    title: 'Pastry Chef',
    subTitle: 'Marriott Bakery Lounge',
    location: 'Islamabad, Pakistan',
    postalCode: '44000',
    jobType: 'Temporary',
    timeAgo: '1 d ago',
    salary: 'Rs. 55,000',
    hour: '/month',
    image: images.businessImg,
    type: 'Temporary',
    status: 'pending',
  },
];


export const frontOfHouseRoles = [
  {id: 1, name: 'Hotel Manager'},
  {id: 2, name: 'Waiter'},
  {id: 3, name: 'busser'},
  {id: 4, name: 'cashier'},
  {id: 5, name: 'Host Staff'},
  {id: 6, name: 'Manager'},
  {id: 7, name: 'Supervisor'},
  {id: 8, name: 'Team Leader'},
];

export const backOfHouseRoles = [
  {id: 1, name: 'Executive Chef'},
  {id: 2, name: 'Sous Chef'},
  {id: 3, name: 'Kitchen Manager'},
  {id: 4, name: 'Grill Chef'},
  {id: 5, name: 'Fry Chef'},
  {id: 6, name: 'Sauce Chef'},
  {id: 7, name: 'Pastry Chef'},
  {id: 8, name: 'Pantry Chef'},
  {id: 9, name: 'Banquet Chef'},
  {id: 10, name: 'Butcher Chef'},
  {id: 11, name: 'Sushi Chef'},
  {id: 12, name: 'Tandoori Chef'},
  {id: 13, name: 'BBQ Pitmaster'},
  {id: 14, name: 'Vegan Chef'},
  {id: 15, name: 'Gluten-Free Chef'},
  {id: 16, name: 'Molecular Gastronomy Chef'},
];

export const rolesData = [
  {id: 1, name: 'Hotel Manager'},
  {id: 2, name: 'Waiter'},
  {id: 3, name: 'busser'},
  {id: 4, name: 'cashier'},
  {id: 5, name: 'Host Staff'},
  {id: 6, name: 'Manager'},
  {id: 7, name: 'Supervisor'},
  {id: 8, name: 'Team Leader'},
  {id: 9, name: 'Executive Chef'},
  {id: 10, name: 'Sous Chef'},
  {id: 11, name: 'Kitchen Manager'},
  {id: 12, name: 'Grill Chef'},
  {id: 13, name: 'Fry Chef'},
  {id: 14, name: 'Sauce Chef'},
  {id: 15, name: 'Pastry Chef'},
  {id: 16, name: 'Pantry Chef'},
  {id: 17, name: 'Banquet Chef'},
  {id: 18, name: 'Butcher Chef'},
  {id: 19, name: 'Sushi Chef'},
  {id: 20, name: 'Tandoori Chef'},
  {id: 21, name: 'BBQ Pitmaster'},
  {id: 22, name: 'Vegan Chef'},
  {id: 23, name: 'Gluten-Free Chef'},
  {id: 24, name: 'Molecular Gastronomy Chef'},
];

export const policies = [
  {
    id: 1,
    title: 'Digital chef Sync – Strike Policy',
    subtitle: 'Digital chef Sync – Strike Policy Signed',
    content: 'Details about strike policies and requirements.',
  },
  {
    id: 2,
    title: 'Alcohol and Drugs Policy',
    subtitle: 'Chef Alcohol and Drugs Policy Signed',
    content: 'This policy ensures a safe and healthy work environment.',
  },
  {
    id: 3,
    title: 'Digital chef Sync Terms for Workers',
    subtitle: 'Chef Policy Provisions Signed',
    content: 'Important terms and conditions for all workers.',
  },
  {
    id: 4,
    title: 'Digital chef Sync Vulnerable Adult Policy',
    subtitle: 'Chef General policy provisions Signed',
    content:
      'Policy ensuring care for vulnerable adults. This policy ensures a safe and healthy work environment. This policy ensures a safe and healthy work environment. This policy ensures a safe and healthy work environment.',
  },
];

export const videoBannerContent = [
  {
    image: images.videoImage1,
    name: 'Digital chef Sync app video explainer',
  },
  {
    image: images.videoImage2,
    name: 'Digital chef Sync Policies',
  },
  {
    image: images.videoImage3,
    name: 'Digital chef Sync Fire Precautions',
  },
  {
    image: images.videoImage4,
    name: 'Digital chef Sync Health and Safety Policy',
  },
  {
    image: images.videoImage5,
    name: 'Digital chef Sync Strike Policy',
  },
];

export const statements = [
  {
    title: 'Statement A',
    description:
      'Do not choose this statement if you’re in receipt of a State, Works or Private Pension. This is my first job since 6 April and since the 6 April I’ve not received payments from any of the following:',
    details: [
      'Jobseeker’s Allowance',
      'Employment and Support Allowance',
      'Incapacity Benefit',
    ],
  },
  {
    title: 'Statement B',
    description:
      'Do not choose this statement if you’re in receipt of a State, Works or Private Pension. Since 6 April I have had another job but I do not have a P45. And/or since the 6 April I have received payments from any of the following:',
    details: [
      'Jobseeker’s Allowance',
      'Employment and Support Allowance',
      'Incapacity Benefit',
    ],
  },
  {
    title: 'Statement C',
    description: 'Choose this statement if:',
    details: [
      'you have another job and/or',
      'you’re in receipt of a State, Works or Private Pension',
    ],
  },
];

export const breakDuration = [
  {label: 'No break', value: 'No break'},
  {label: '10 minute', value: '10 minute'},
  {label: '20 minute', value: '20 minute'},
  {label: '30 minute', value: '30 minute'},
  {label: '40 minute', value: '40 minute'},
  {label: '50 minute', value: '50 minute'},
];

export const demoMessages = [
  {
    id: '1',
    text: 'Hey! How are you doing?',
    senderId: 'user4',
    timestamp: Date.now() - 600000,
  },
  {
    id: '2',
    text: 'I’m good! Working on the project.',
    senderId: 'user1',
    timestamp: Date.now() - 580000,
  },
  {
    id: '3',
    text: 'Awesome! Let me know if you need help.',
    senderId: 'user2',
    timestamp: Date.now() - 550000,
  },
  {
    id: '4',
    text: 'Sure. Just fixing some bugs now.',
    senderId: 'user1',
    timestamp: Date.now() - 520000,
  },
  {
    id: '5',
    text: 'Did you push the latest code to GitHub?',
    senderId: 'user2',
    timestamp: Date.now() - 500000,
  },
  {
    id: '6',
    text: 'Yes, just did it 10 minutes ago.',
    senderId: 'user1',
    timestamp: Date.now() - 480000,
  },
  {
    id: '7',
    text: 'Great! I’ll review and update the UI flow.',
    senderId: 'user2',
    timestamp: Date.now() - 460000,
  },
  {
    id: '8',
    text: 'Cool. Also thinking of changing the login screen.',
    senderId: 'user1',
    timestamp: Date.now() - 440000,
  },
  {
    id: '9',
    text: 'Oh? What’s the new idea?',
    senderId: 'user2',
    timestamp: Date.now() - 420000,
  },
  {
    id: '10',
    text: 'More minimalist. Dark background with gold text.',
    senderId: 'user1',
    timestamp: Date.now() - 400000,
  },
];

export const dummyChats = [
  {
    _id: 'user2',
    latestMessage: {
      senderId: 'user2',
      receiverId: 'Ali Ahmed',
      text: 'Hey! How are you?',
      timestamp: Date.now() - 5000,
    },
  },
  {
    _id: 'user3',
    latestMessage: {
      senderId: 'user1',
      receiverId: 'Asad Khan',
      text: 'Project file sent!',
      timestamp: Date.now() - 15000,
    },
  },
  {
    _id: 'user4',
    latestMessage: {
      senderId: 'user4',
      receiverId: 'Hamza Ali',
      text: 'Thanks for the update.',
      timestamp: Date.now() - 45000,
    },
  },
  {
    _id: 'user5',
    latestMessage: {
      senderId: 'user1',
      receiverId: 'Saad Siddiqui',
      text: 'Let’s meet tomorrow.',
      timestamp: Date.now() - 120000,
    },
  },
];

export const notifications = [
  {
    id: '1',
    title: 'Weekly invoice',
    message: 'Your weekly invoice of £19.79 has been created.',
  },
  {
    id: '2',
    title: 'Checkout recorded',
    message:
      'Hammad Ali has checked out of their Barista job. You can now view their hours of work.',
  },
  {
    id: '3',
    title: 'Checkout recorded',
    message:
      'Hammad Ali has checked out of their Barista job. You can now view their hours of work.',
  },
  {
    id: '4',
    title: 'Job application received',
    message:
      'Hammad Ali has applied for Barista job. Please check job applications to hire or reject applicants.',
  },
  {
    id: '5',
    title: 'Job post approved',
    message: 'Your Barista job post has been approved and can now be viewed.',
  },
  {
    id: '6',
    title: 'Job post pending',
    message: 'Your Barista job has been submitted and is awaiting approval.',
  },
];

export const invoices = [
  {id: '00002', date: '23-11-2024', amount: 26.18, status: 'pending'},
  {id: '00003', date: '25-11-2024', amount: 17.93, status: 'pending'},
  {id: '00004', date: '26-11-2024', amount: 17.53, status: 'pending'},
  {id: '00011', date: '08-02-2025', amount: 1.17, status: 'pending'},
  {id: '00014', date: '09-02-2025', amount: 0.03, status: 'paid'},
];

export const basicFeatures = [
  {label: 'Profile Creation', available: true},
  {label: 'Job Notifications', available: false},
  {label: 'Invoicing', available: false},
  {label: 'Apply Only 10 Jobs', available: true},
  {label: 'Chats Access', available: false},
  {label: 'Priority Applications', available: false},
];

export const premiumFeatures = [
  {label: 'Profile Creation', available: true},
  {label: 'Skill-Based Notifications', available: true},
  {label: 'Unlimited Invoicing', available: true},
  {label: 'Apply Unlimited Jobs', available: true},
  {label: 'Chats Access', available: true},
  {label: 'Priority Applications', available: true},
];

export const businessBasicFeatures = [
  {label: 'One Month Trail', available: true},
  {label: 'Only 2 Job Posts', available: true},
  {label: 'Profile Edit', available: true},
  {label: 'Job Notifications', available: false},
  {label: 'Invoicing', available: false},
];

export const BusinessPremiumFeatures = [
  {label: 'Full Month Access', available: true},
  {label: 'Unlimited Job Posts', available: true},
  {label: 'Profile Edit', available: true},
  {label: 'Skill-Based Notifications', available: true},
  {label: 'Unlimited Invoicing', available: true},
];

export const faqData = [
  {
    question: 'How do I brief a team member?',
    answer:
      'You can brief the team member by including all necessary information in the job listing or by messaging the staff once they are booked on. Include details such as venue directions, access points, dress code, and contact info.',
  },
  {
    question: 'What if a Digital Chef Sync needs to stay beyond booked hours?',
    answer:
      'If a Digital Chef Sync is required to stay beyond the scheduled time, please inform them in advance and approve the extra hours in the app. Extra time may incur additional charges.',
  },
  {
    question: 'How do I handle billing and invoicing?',
    answer:
      'Invoices are automatically generated after job completion and can be accessed in the Billing section of the app. You’ll receive a summary via email as well.',
  },
  {
    question: 'How much does it cost to use the digital chef sync App?',
    answer:
      'Using the digital chef sync App is free for clients. You only pay for the chefs or staff you book. No subscription or hidden fees apply.',
  },
  {
    question: 'How am I charged for a booking?',
    answer:
      'Charges are calculated based on the hourly rate of the chef and the total hours worked. Any additional time or special requirements may add to the cost.',
  },
  {
    question: 'When is the money taken from my account?',
    answer:
      'Payment is typically processed after the job is completed and confirmed. A hold may be placed on your payment method at the time of booking.',
  },
];

export const reviews = [
  {
    id: '1',
    name: 'Anas Siddiqui',
    rating: 4.5,
    comment: 'The professionalism and culinary expertise exceeded our expectations. Hygiene standards were impeccable and the communication was smooth throughout. Highly dependable.',
    avatar:images.chefDress1,
  },
  {
    id: '2',
    name: 'Abu Bakar',
    rating: 3,
    comment: `One of the most seamless culinary experiences we've had. The chef brought a restaurant-level atmosphere into our home. Will definitely book again for future private dinners.`,
  },
  {
    id: '3',
    name: 'Saad Siddiqui',
    rating: 5,
    comment: 'Good work',
    avatar:images.chefDress1,
  },
  {
    id: '4',
    name: 'Hammad Ali',
    rating: 4.5,
    comment: 'Truly outstanding service. The chef curated a bespoke menu that impressed all our guests. Everything from taste to timing was flawless. An asset for any high-end event',
  },
  {
    id: '5',
    name: 'Ali',
    rating: 3,
    comment:
      'Exceptional culinary experience. The chef demonstrated remarkable professionalism, punctuality, and attention to detail. Every dish was prepared with finesse, and the presentation was restaurant-quality. Highly recommended for private dining events or high-end catering',
  },
];