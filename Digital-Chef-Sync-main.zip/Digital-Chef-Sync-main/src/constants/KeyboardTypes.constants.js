export const keyboardTypes = {
  emailAddress: 'email-address',
  default: 'default',
};
