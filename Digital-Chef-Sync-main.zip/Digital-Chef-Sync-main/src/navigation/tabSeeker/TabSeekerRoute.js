import Home from '../../screens/seeker/home/Home';
import MessagesListScreen from '../../screens/seeker/messagesListScreen/MessagesListScreen';
import NotificationsScreen from '../../screens/seeker/notifications/NotificationsScreen';
import ProfileScreen from '../../screens/seeker/profile/ProfileScreen';
import ShiftsScreen from '../../screens/seeker/shifts/ShiftsScreen';


export const tabSeekerRoutes = [
  {
    name: 'Home',
    component: Home,
  },
  {
    name: 'Shifts',
    component: ShiftsScreen,
  },
  {
    name: 'Messages',
    component: MessagesListScreen,
  },
  {
    name: 'Alert',
    component: NotificationsScreen,
  },
  {
    name: 'Profile',
    component: ProfileScreen,
  },
];
