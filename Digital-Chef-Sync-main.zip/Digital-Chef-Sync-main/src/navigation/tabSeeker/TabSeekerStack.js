/* eslint-disable react/react-in-jsx-scope */
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import BottomTabSeeker from '../../components/bottomTabSeeker/bottomTabSeeker';
import {tabSeekerRoutes} from './TabSeekerRoute';

const BottomTabStack = createBottomTabNavigator();

const routes = tabSeekerRoutes;

const TabSeekerStack = () => {
  return (
    <BottomTabStack.Navigator tabBar={props => <BottomTabSeeker {...props} />}>
      {routes.map(data => {
        return (
          <BottomTabStack.Screen
            options={{headerShown: false}}
            name={data?.name}
            component={data?.component}
          />
        );
      })}
    </BottomTabStack.Navigator>
  );
};

export default TabSeekerStack;
