import BusinessOnBoarding from '../../screens/business/onBoarding.js/BusinessOnBoarding';
import SeekerOnBoarding from '../../screens/seeker/onBoarding/SeekerOnBoarding';
import SignUp from '../../screens/signUp/SignUp';
import SignIn from '../../screens/signIn/SignIn';
import Plans from '../../screens/seeker/onBoarding/plans/Plans';
import BusinessPlans from '../../screens/business/onBoarding.js/plans/BusinessPlans';
import WelcomeScreen from '../../screens/welcomeToChefsync/WelcomeScreen';

export const authRoutes = [
  {
    name: 'WelcomeScreen',
    component: WelcomeScreen,
  },
  {
    name: 'SignIn',
    component: SignIn,
  },
  {
    name: 'SignUp',
    component: SignUp,
  },
  {
    name: 'SeekerOnBoarding',
    component: SeekerOnBoarding,
  },
  {
    name: 'BusinessOnBoarding',
    component: BusinessOnBoarding,
  },
  {
    name: 'SeekerPlan',
    component: Plans,
  },
  {
    name: 'BusinessPlan',
    component: BusinessPlans,
  },
];
