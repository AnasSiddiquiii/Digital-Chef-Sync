import { TermsAndConditions } from '../../screens/termsAndConditions/TermsAndConditions';
import SelectRole from '../../screens/business/jobCreate/shiftCreateForms/SelectRole';
import { PrivacyPolicy } from '../../screens/privacyPolicy/PrivacyPolicy';
import BrowserJob from '../../screens/browserJob/BrowserJob';
import JobDetail from '../../screens/jobDetail/JobDetail';
import Splash from '../../screens/splash/Splash';
import CVLive from '../../screens/cvLive/CVLive';
import Intro from '../../screens/intro/Intro';
import WelcomeScreen from '../../screens/welcomeToChefsync/WelcomeScreen';
import ShiftDetail from '../../screens/business/jobCreate/shiftCreateForms/ShiftDetail';
import MessageScreen from '../../screens/business/messageListScreen/messageScreen/MessageScreen';
import ReviewListScreen from '../../screens/reviewListScreen/ReviewListScreen';
import HelpSupportScreen from '../../screens/helpSupportScreen/HelpSupportScreen';
import FAQScreen from '../../screens/faq\'s/FAQs';
import ChangePasswordScreen from '../../screens/changePassword/ChangePassword';
import EditProfileSeeker from '../../screens/seeker/editProfile/EditProfile';
import EditProfileBusiness from '../../screens/business/editProfile/EditProfile';
import PaymentsScreenSeeker from '../../screens/seeker/walletScreen/walletScreen';
import PaymentsScreenBusiness from '../../screens/business/paymentsScreen/PaymentsScreen';
import WalletScreen from '../../screens/seeker/walletScreen/walletScreen';


export const appRoutes = [
  {
    name: 'Splash',
    component: Splash,
  },
  {
    name: 'Intro',
    component: Intro,
  },
  {
    name: 'CVLive',
    component: CVLive,
  },
  {
    name: 'BrowserJob',
    component: BrowserJob,
  },
  {
    name: 'JobDetail',
    component: JobDetail,
  },
  {
    name: 'PrivacyPolicy',
    component: PrivacyPolicy,
  },
  {
    name: 'TermsAndConditions',
    component: TermsAndConditions,
  },
  {
    name: 'SelectRole',
    component: SelectRole,
  },
  {
    name: 'ShiftDetail',
    component: ShiftDetail,
  },
  {
    name: 'MessageScreen',
    component: MessageScreen,
  },
  {
    name: 'WalletScreen',
    component: WalletScreen,
  },
  {
    name: 'PaymentScreen',
    component: PaymentsScreenBusiness,
  },
  {
    name: 'ReviewListScreen',
    component: ReviewListScreen,
  },
  {
    name: 'HelpSupportScreen',
    component: HelpSupportScreen,
  },
  {
    name: 'FAQs',
    component: FAQScreen,
  },
  {
    name: 'ChangePasswordScreen',
    component: ChangePasswordScreen,
  },
  {
    name: 'EditProfileSeeker',
    component: EditProfileSeeker,
  },
  {
    name: 'EditProfileBusiness',
    component: EditProfileBusiness,
  },
];
