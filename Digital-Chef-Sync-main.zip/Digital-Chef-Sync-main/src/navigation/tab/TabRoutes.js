import ShiftsScreen from '../../screens/business/jobCreate/ShiftScreen';
import MessageListScreen from '../../screens/business/messageListScreen/MessageListScreen';
import NotificationScreen from '../../screens/business/notification/Notification';
import ProfileScreen from '../../screens/business/profile/ProfileScreen';


export const tabRoutes = [
  {
    name: 'Shifts',
    component: ShiftsScreen,
  },
  {
    name: 'Messages',
    component: MessageListScreen,
  },
  {
    name: 'Notifications',
    component: NotificationScreen,
  },
  {
    name: 'Profile',
    component: ProfileScreen,
  },
];
