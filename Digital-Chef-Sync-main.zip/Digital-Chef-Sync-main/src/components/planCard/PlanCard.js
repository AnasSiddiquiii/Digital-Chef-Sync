import React, {useState} from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import {styles} from './PlanCard.style';

const PlanCard = ({handleNavigation, basicFeatures, premiumFeatures}) => {
  const [selectedPlan, setSelectedPlan] = useState('Basic');

  const plans = {
    Basic: {
      price: '0',
      cents: '00',
      features: basicFeatures,
      buttonLabel: 'GET STARTED',
    },
    Premium: {
      price: '999',
      cents: '99',
      features: premiumFeatures,
      buttonLabel: 'BUY NOW',
    },
  };

  const plan = plans[selectedPlan];

  return (
    <View style={styles.container}>
      {/* Tabs */}
      <View style={styles.tabs}>
        {['Basic', 'Premium'].map(type => (
          <TouchableOpacity key={type} onPress={() => setSelectedPlan(type)}>
            <Text
              style={[
                styles.tab,
                selectedPlan === type ? styles.activeTab : styles.inactiveTab,
              ]}>
              {type}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Card */}
      <View style={styles.card}>
        {/* Price */}
        <View style={styles.priceWrapper}>
          <Text style={styles.dollar}>Rs</Text>
          <Text style={styles.price}>{plan.price}</Text>
          <Text style={styles.cents}>.{plan.cents}</Text>
          <Text style={styles.perMonth}>/month</Text>
        </View>

        {/* Features */}
        <View style={styles.features}>
          {plan.features.map((feature, index) => (
            <View key={index} style={styles.featureItem}>
              <Text
                style={{
                  color: feature.available ? 'black' : 'red',
                  fontSize: 16,
                  marginRight: 8,
                }}>
                {feature.available ? '✔' : '✘'}
              </Text>
              <Text style={styles.featureText}>{feature.label}</Text>
            </View>
          ))}
        </View>

        {/* Button */}
        <TouchableOpacity
          onPress={handleNavigation}
          style={styles.button}>
          <Text style={styles.buttonText}>{plan.buttonLabel}</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default PlanCard;
