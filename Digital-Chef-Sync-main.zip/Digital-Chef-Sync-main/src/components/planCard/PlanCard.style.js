import { StyleSheet } from "react-native";
import colors from "../../config/Colors";

export const styles = StyleSheet.create({
  container: {
    padding: 16,
  },
  tabs: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: 12,
  },
  tab: {
    paddingVertical: 6,
    paddingHorizontal: 16,
    marginHorizontal: 6,
    borderRadius: 20,
    fontSize: 18,
    fontWeight: '600',
  },
  activeTab: {
    backgroundColor: colors.bgPrimary,
    color: colors.secondary,
  },
  inactiveTab: {
    color: colors.primary,
    borderColor:colors.primary,
    borderWidth:0.8
  },
  card: {
    backgroundColor: colors.bgPrimary,
    borderRadius: 16,
    padding: 20,
  },
  priceWrapper: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'center',
    marginBottom: 20,
  },
  dollar: {
    fontSize: 25,
    fontWeight: '600',
    marginRight: 2,
  },
  price: {
    fontSize: 55,
    fontWeight: 'bold',
  },
  cents: {
    fontSize: 20,
    marginBottom: 6,
    marginLeft: 2,
  },
  perMonth: {
    fontSize: 20,
    marginLeft: 6,
    marginBottom: 10,
    color: colors.secondary,
    fontWeight:"700"
  },
  features: {
    marginBottom: 20,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 6,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.secondary,
    marginRight: 10,
  },
  featureText: {
    fontSize: 20,
    color: colors.secondary,
  },
  button: {
    backgroundColor: colors.bgSecondary,
    paddingVertical: 12,
    borderRadius: 16,
    alignItems: 'center',
  },
  buttonText: {
    color: colors.primary,
    fontSize: 14,
  },
});
