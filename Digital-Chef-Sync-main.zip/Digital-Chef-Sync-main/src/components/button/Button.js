import { Text, TouchableOpacity, View } from 'react-native';
import React, { memo } from 'react';
import Icon from 'react-native-vector-icons/FontAwesome';

import Styles from './Button.style';

const Button = ({
  onPress = () => {},
  text = '',
  iconName = null,
  iconSize = 24,
  iconColor = 'black',
  textStyle = Styles.textStyle,
  additionalStyle = {},
  additionalTestStyle = {},
}) => {
  return (
    <TouchableOpacity
      onPress={onPress}
      style={[Styles.buttonStyle, additionalStyle]}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center' }}>
        {iconName && (
          <Icon
            name={iconName}
            size={iconSize}
            color={iconColor}
            style={{ marginRight: 15 }}
          />
        )}
        <Text style={[textStyle, additionalTestStyle]}>{text}</Text>
      </View>
    </TouchableOpacity>
  );
};

export default memo(Button);
