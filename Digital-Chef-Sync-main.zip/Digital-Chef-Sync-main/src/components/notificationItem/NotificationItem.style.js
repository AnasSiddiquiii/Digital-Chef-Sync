import { StyleSheet } from 'react-native';
import colors from '../../config/Colors';

export const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: colors.bgSecondary, // Darker black for card
    padding: 14,
    borderRadius: 12,
    marginBottom: 15,
    borderLeftWidth: 4,
    borderLeftColor: colors.primary, // Gold accent
    shadowColor: colors.primary,
    shadowOpacity: 0.2,
    shadowOffset: { width: 0, height: 1 },
    shadowRadius: 3,
    elevation: 3,
  },
  icon: {
    width: 45,
    height: 60,
    resizeMode: 'contain',
    borderRadius: 21,
    marginRight: 12,
  },
  textContainer: {
    flex: 1,
    paddingRight: 10,
  },
  title: {
    fontWeight: 'bold',
    fontSize: 16,
    color: colors.primary, // Golden title
    marginBottom: 2,
  },
  message: {
    color: colors.accentLight, // Light grey message text
    fontSize: 14,
  },
  dot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: colors.bgPrimary, // Golden dot
    marginTop: 6,
  }
});
