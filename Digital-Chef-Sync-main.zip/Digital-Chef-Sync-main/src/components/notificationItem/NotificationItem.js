import { Text } from "react-native";
import { Image, View } from "react-native";
import { images } from "../../config/Images";
import { styles } from "./NotificationItem.style";


const NotificationItem = ({title, message}) => (
  <View style={styles.card}>
    <Image
      source={images.splashImg} 
      style={styles.icon}
    />
    <View style={styles.textContainer}>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.message}>{message}</Text>
    </View>
    <View style={styles.dot} />
  </View>
);

export default NotificationItem