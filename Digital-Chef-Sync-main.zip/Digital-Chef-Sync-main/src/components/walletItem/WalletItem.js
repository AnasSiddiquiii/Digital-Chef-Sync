import React from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import {styles} from './WalletItem.style';

export default function WalletItem({item}) {
  const isPaid = item.status === 'paid';

  return (
    <View style={styles.invoiceCard}>
      <Text style={styles.dateText}>Date: {item.date}</Text>
      <Text style={styles.invoiceText}>Invoice no: {item.id}</Text>

      <View style={styles.row}>
        <Text style={[styles.amountText, {color: isPaid ? 'green' : 'red'}]}>
          {item.amount.toFixed(2)}
        </Text>

        <TouchableOpacity
          style={[
            styles.button,
            isPaid ? styles.paidButton : styles.unpaidButton,
          ]}
          disabled>
          <Text style={styles.buttonText}>{isPaid ? 'Paid' : 'Unpaid'}</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}
