// components/DateTimeInput.js
import React, {useState} from 'react';
import {View, Text, Platform, Pressable} from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';

const DateTimeInput = ({label = '', onChange}) => {
  const [date, setDate] = useState(new Date());
  const [showPicker, setShowPicker] = useState(false);
  const [mode, setMode] = useState('date');
  const [isPicked, setIsPicked] = useState(false);

  const showMode = currentMode => {
    setMode(currentMode);
    setShowPicker(true);
  };

  const onDateTimeChange = (event, selectedValue) => {
    if (selectedValue) {
      const currentDate = selectedValue;
      setShowPicker(false);

      if (mode === 'date') {
        // Set date and switch to time mode
        setDate(prevDate => {
          const newDate = new Date(
            currentDate.getFullYear(),
            currentDate.getMonth(),
            currentDate.getDate(),
            prevDate.getHours(),
            prevDate.getMinutes(),
          );
          showMode('time');
          return newDate;
        });
      } else {
        // Set time, combine with selected date
        setDate(prevDate => {
          const finalDate = new Date(
            prevDate.getFullYear(),
            prevDate.getMonth(),
            prevDate.getDate(),
            currentDate.getHours(),
            currentDate.getMinutes(),
          );
          setIsPicked(true);
          onChange && onChange(finalDate);
          return finalDate;
        });
      }
    } else {
      setShowPicker(false); // Cancelled
    }
  };

  return (
    <View style={{marginVertical: 10}}>
      <Pressable
        onPress={() => showMode('date')}
        style={{
          paddingHorizontal: 10,
          paddingVertical: 14,
          backgroundColor: 'black',
          borderRadius: 16,
          borderWidth: 1,
          borderColor: 'white',
        }}>
        <Text style={{color: 'gray', fontSize:15}}>
          {isPicked ? date.toLocaleString() : `${label}`}
        </Text>
      </Pressable>

      {showPicker && (
        <DateTimePicker
          value={date}
          mode={mode}
          is24Hour={true}
          display="default"
          onChange={onDateTimeChange}
        />
      )}
    </View>
  );
};

export default DateTimeInput;
