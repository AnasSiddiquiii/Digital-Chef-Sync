import { View, Text, Image, ScrollView } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import React from 'react';

import { images } from '../../config/Images';
import Button from '../button/Button';
import { styles } from './jobDetailScreen.style';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const roles = [
  'Executive Chef',
  'Sous Chef',
  'Kitchen Manager',
  'Grill Chef',
  'Fry Chef',
  'Sauce Chef',
  'Team Leader',
];

const JobDetailScreen = () => {
  const { bottom } = useSafeAreaInsets();

  return (
    <ScrollView
      style={styles.container}
      showsVerticalScrollIndicator={false}
      contentContainerStyle={{ marginBottom: bottom }}
    >
      {/* Header Section */}
      <View style={styles.header}>
        <Image source={images.splashImg} style={styles.logo} />
        <View style={styles.headerText}>
          <Text style={styles.title}>Event Coordinator</Text>
          <View style={styles.ratingContainer}>
            <Icon name="star" size={16} color="#FFD700" />
            <Text style={styles.rating}>4.9</Text>
            <Text style={styles.daysAgo}>2d ago</Text>
          </View>
        </View>
      </View>

      {/* Pay Details */}
      <View style={styles.payContainer}>
        <Text style={styles.rate}>Hourly Rate (including overtime)</Text>
        <Text style={styles.salary}>Rs. 1,200</Text>
        <Text style={styles.approxSalary}>Approximate Monthly Salary</Text>
        <Text style={styles.salary}>Rs. 95,000</Text>
      </View>

      {/* Shift Date & Time */}
      <Text style={styles.sectionHeader}>Shift Date & Time</Text>
      <Text style={styles.location}>📍 Gaddafi Stadium, Lahore, 54660</Text>
      {[...Array(4)].map((_, index) => (
        <Text key={index} style={styles.shiftTime}>
          📅 30-07-2025 | 06:00 PM - 11:30 PM
        </Text>
      ))}

      {/* Warning Message */}
      <View style={styles.warningContainer}>
        <Icon name="exclamation-circle" size={18} color="#D32F2F" />
        <Text style={styles.warning}>
          Please note: Only applicants residing in Pakistan are eligible.
        </Text>
      </View>

      {/* Event Details */}
      <Text style={styles.eventName}>Event Name: PSL Closing Ceremony</Text>
      <Text style={styles.eventDescription}>
        Event Description: Join the celebration of Pakistan Super League's grand finale at Gaddafi Stadium.
      </Text>

      {/* About Job Section */}
      <Text style={styles.aboutJobHeader}>About Job</Text>
      <Text style={styles.aboutJobText}>
        We are seeking passionate hospitality staff for one of the biggest events of the year. You'll be part of a high-energy team ensuring guest satisfaction throughout the event.
      </Text>
      <Text style={styles.headingRole}>Role name:</Text>
      {roles.map((role, index) => (
        <Text key={index} style={styles.roleItem}>
          • {role}
        </Text>
      ))}

      {/* Select Shift Button */}
      <Button text="Select Shift" />
    </ScrollView>
  );
};

export default JobDetailScreen;
