import {StyleSheet} from 'react-native';
import colors from '../../config/Colors';

export const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: colors.bgSecondary,
    borderRadius: 16,
    flexGrow: 1,
    marginBottom: 25,
  },
  header: {flexDirection: 'row', alignItems: 'center', marginBottom: 10},
  logo: {width: 50, height: 50, borderRadius: 25, marginRight: 10},
  headerText: {flex: 1},
  title: {fontSize: 18, fontWeight: 'bold', color: colors.primary},
  ratingContainer: {flexDirection: 'row', alignItems: 'center', marginTop: 4},
  rating: {fontSize: 14, color: colors.accentLight, marginLeft: 5},
  daysAgo: {fontSize: 12, color: colors.accentLight, marginLeft: 10},
  payContainer: {
    backgroundColor: colors.bgPrimary,
    padding: 10,
    borderRadius: 10,
    marginVertical: 10,
  },
  rate: {fontSize: 16, color: colors.secondary},
  salary: {fontSize: 18, fontWeight: 'bold', color: colors.secondary},
  approxSalary: {fontSize: 16, color: colors.secondary, marginTop: 10},
  sectionHeader: {
    fontSize: 16,
    fontWeight: 'bold',
    color: colors.primary,
    marginTop: 10,
  },
  location: {fontSize: 14, color: colors.accentLight, marginBottom: 5},
  shiftTime: {fontSize: 14, color: colors.primary, marginBottom: 5},
  warningContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FEE2E2',
    padding: 10,
    borderRadius: 5,
    marginBottom: 10,
  },
  warning: {marginLeft: 10, color: '#B91C1C', fontSize: 14},
  eventName: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 0,
    color: colors.primary,
  },
  eventDescription: {fontSize: 14, color: colors.accentLight, marginBottom: 10},
  aboutJobHeader: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
    color: colors.primary,
  },
  aboutJobText: {fontSize: 14, color: '#555', marginBottom: 20},

  headingRole: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
    color: colors.primary,
  },
  roleItem: {
    fontSize: 14,
    paddingVertical: 4,
    color: colors.accentLight,
    marginBottom:4
  },
});
