import { StyleSheet } from 'react-native';
import colors from '../../config/Colors';

export const styles = StyleSheet.create({
  invoiceCard: {
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
    backgroundColor:colors.bgPrimary
  },
  dateText: {
    fontSize: 14,
    marginBottom: 5,
  },
  invoiceText: {
    fontSize: 14,
    marginBottom: 10,
  },
  amountText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  button: {
    borderRadius: 6,
    paddingVertical: 6,
    paddingHorizontal: 12,
  },
  authButton: {
    backgroundColor: '#FF4500',
  },
  paidButton: {
    backgroundColor: '#008000',
  },
  buttonText: {
    color: '#fff',
    fontWeight: '600',
  },
});
