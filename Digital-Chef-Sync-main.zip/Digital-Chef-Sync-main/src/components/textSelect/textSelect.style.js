// RolesSelectionScreen.style.js
import { StyleSheet } from "react-native";
import colors from "../../config/Colors";


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bgSecondary,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 10,
  },
  roleContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 10,
    marginVertical: 5,
    borderWidth: 1,
    borderColor: colors.primary,
    borderRadius: 10,
  },
  roleText: {
    flex: 1,
    fontSize: 16,
    paddingLeft: 10,
    paddingVertical:2,
    color:colors.accent
  },
  selectedRole: {
    borderColor: colors.primary,
  },
  disabledRole: {
    backgroundColor: "#f2f2f2",
    borderColor: "#ddd",
  },
  disabledText: {
    color: "#b0b0b0",
  },
});

export default styles;
