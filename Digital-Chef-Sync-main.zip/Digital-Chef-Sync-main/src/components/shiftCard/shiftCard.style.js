import { StyleSheet } from "react-native";

import colors from "../../config/Colors";


const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.bgSecondary,
    borderRadius: 10,
    marginVertical: 5,
    borderWidth: 0.8,
    borderColor: colors.accentLight,
  },
  card: {
    padding: 10,
  },
  date: {
    fontSize: 12,
  },
  body: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  logo: {
    width: 40,
    height: 40,
    marginRight: 10,
    borderRadius: 5,
  },
  title: {
    fontSize: 18,
    fontWeight: '500',
    color:colors.primary
  },
  subTitle: {
    fontSize: 12,
    color:colors.accentLight
  },
  dateRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: "space-between",
    color:colors.accentLight
  },
  location: {
    fontSize: 12,
    textAlign: "center",
    paddingBottom: 5,
    color:colors.accentLight
  },
  timeAgo: {
    color: colors.accentLight,
    fontSize: 12,
    paddingBottom: 5,
    textAlign: "right",
    color:colors.accentLight

  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
  },
  jobType: {
    color: colors.secondary,
    fontWeight: 'bold',
    fontSize: 11,
    backgroundColor: colors.bgPrimary,
    textAlign: "center",
    paddingVertical: 1.2,
    borderRadius: 20,
    width:80
  },
  salary: {
    fontSize: 15,
    fontWeight: 'bold',
    color:colors.primary
  },
  hour: {
    fontSize: 14,
    color: colors.accentLight,
  },
  btnContainer: {
    flexDirection: "row",
    width: "100%",
    alignItems: "center",
    justifyContent: "space-between",

  },
  reviewBtn: {
    width: "50%",
    borderRadius: 0,
    backgroundColor: colors.bgSecondary,
    borderColor: colors.accentLight,
    borderTopWidth: 0.5,
    borderRightWidth: 0.5,
    borderBottomLeftRadius:10
  },
  reviewBtnText: {
    color: colors.primary
  },
  detailBtn: {
    borderRadius: 0,
    backgroundColor: colors.bgSecondary,
    borderColor: colors.accentLight,
    borderTopWidth: 0.5,
    borderBottomRightRadius:10,
    borderBottomLeftRadius:10
  },
  detailBtnText: {
    color: colors.accentLight
  },
});

export default styles;