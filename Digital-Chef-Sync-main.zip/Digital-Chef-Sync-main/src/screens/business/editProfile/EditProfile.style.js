// styles.js
import { StyleSheet } from 'react-native';
import colors from '../../../config/Colors';

export const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.bgSecondary,
    flex:1
  },
  profileImageContainer: {
    alignItems: 'center',
    paddingVertical: 30,
  },
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
  },
  cameraIcon: {
    position: 'absolute',
    right: 300 / 2 - 15,
    bottom: 20,
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 5,
    elevation: 5,
  },
  cameraIconText: {
    fontSize: 18,
  },
  title: {
    fontSize: 24,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 20,
    color:colors.primary
  },
  input: {
    borderWidth: 1,
    borderColor: '#aaa',
    borderRadius: 10,
    padding: 10,
    marginBottom: 15,
  },
  textArea: {
    height: 100,
    textAlignVertical: 'top',
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  halfInput: {
    width: '48%',
  },
  updatePassword: {
    textAlign: 'center',
    textDecorationLine: 'underline',
    color: 'black',
    marginBottom: 20,
  }
});
