import {StyleSheet} from 'react-native';
import colors from '../../../config/Colors';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bgSecondary,
  },
  subContainer: {padding: 16},
  headerText: {
    fontWeight: 'bold',
    fontSize: 16,
    marginTop: 10,
    color: colors.primary,
  },
  valueText: {
    fontSize: 18,
    color: colors.secondary,
    backgroundColor: colors.primary,
    padding: 10,
    marginBottom: 5,
  },
  totalText: {
    fontSize: 18,
    color: colors.secondary,
    backgroundColor: colors.primary,
    padding: 10,
    marginBottom: 20,
  },
});
