import {StyleSheet} from 'react-native';
import colors from '../../../config/Colors';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bgPrimary,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingVertical: 16,
  },
  headerTitle: {
    color: colors.secondary,
    fontSize: 22,
    fontWeight: '600',
  },
  iconButton: {
    padding: 8,
    borderWidth: 1,
    borderColor: colors.secondary,
    borderRadius: 10,
  },
  profileSection: {
    alignItems: 'center',
    marginTop: 8,
    marginBottom: 40,
  },
  profileImage: {
    width: 110,
    height: 110,
    borderRadius: 48,
    borderWidth: 2,
    borderColor: colors.secondary,
  },
  username: {
    color: colors.secondary,
    fontSize: 20,
    fontWeight: '600',
    marginTop: 10,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 6,
  },
  ratingText: {
    color: colors.secondary,
    marginLeft: 5,
  },
  menuContainer: {
    backgroundColor: colors.bgSecondary,
    flex: 1,
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    paddingTop: 20,
    paddingHorizontal: 18,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderColor: colors.bgPrimary,
  },
  menuIconBox: {
    backgroundColor: colors.primary,
    padding: 8,
    borderRadius: 10,
    marginRight: 14,
  },
  menuLabel: {
    color: colors.primary,
    fontSize: 16,
    fontWeight: '500',
  },
});
