import { StyleSheet } from 'react-native';
import colors from '../../../../config/Colors';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bgSecondary,
  },
  content: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  subContainer: {
    width: '100%',
    maxWidth: 400,
  },
  heading: {
  fontSize: 35,
  fontWeight: '700',
  textAlign: 'center',
  color: colors.primary,
  paddingBottom: 20,
  paddingHorizontal:20
},

});
