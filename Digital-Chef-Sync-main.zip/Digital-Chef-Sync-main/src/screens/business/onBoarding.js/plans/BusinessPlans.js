import React, {useCallback} from 'react';
import {ScrollView, Text, View} from 'react-native';
import PlanCard from '../../../../components/planCard/PlanCard';
import {styles} from './BusinessPlans.style';
import {businessBasicFeatures, BusinessPremiumFeatures} from '../../../../constants/constant';
import {changeStack, navigate} from '../../../../navigation/NavigationService';

const BusinessPlans = () => {
  const handleNavigation = useCallback(
    () => changeStack('TabStack'),
    [],
  );
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.subContainer}>
        <Text style={styles.heading}>Unlock Powerful Features</Text>
        <PlanCard
          basicFeatures={businessBasicFeatures}
          premiumFeatures={BusinessPremiumFeatures}
          handleNavigation={handleNavigation}
        />
      </View>
    </ScrollView>
  );
};

export default BusinessPlans;
