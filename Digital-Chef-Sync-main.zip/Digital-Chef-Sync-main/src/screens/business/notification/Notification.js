import {View, Text, FlatList, Image} from 'react-native';
import {styles} from './Notification.style';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import NotificationItem from '../../../components/notificationItem/NotificationItem';
import { notifications } from '../../../constants/constant';


export default function NotificationScreen() {
  const {top} = useSafeAreaInsets();

  return (
    <View style={[styles.container, {paddingTop: top}]}>
      <Text style={styles.heading}>Notifications</Text>
      <View style={styles.subContainer}>
        <FlatList
          showsVerticalScrollIndicator={false}
          data={notifications}
          keyExtractor={item => item.id}
          renderItem={({item}) => (
            <NotificationItem title={item.title} message={item.message} />
          )}
        />
      </View>
    </View>
  );
}
