import { StyleSheet } from 'react-native';
import colors from '../../../config/Colors';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor:colors.bgSecondary, // Black background
  },
  subContainer: {
    paddingVertical:15,
    paddingHorizontal:16,
  },
  heading: {
    color: colors.primary,
    fontSize: 25,
    textAlign: 'center',
    paddingVertical: 10,
    fontWeight:"700"
  },
});
