import {
  Image,
  Text,
  View,
  TouchableOpacity,
  Alert,
  KeyboardAvoidingView,
  PermissionsAndroid,
  Platform,
} from 'react-native';
import {ScrollView} from 'react-native';
import React, {useState} from 'react';
import {Formik} from 'formik';
import * as Yup from 'yup';

import {navigate} from '../../../../navigation/NavigationService';
import {launchCamera, launchImageLibrary} from 'react-native-image-picker';
import Header from '../../../../components/header/Header';
import Button from '../../../../components/button/Button';
import Input from '../../../../components/input/Input';
import {shiftDetail as styles} from './allJobForm.style';
import {images} from '../../../../config/Images';
import Label from '../../../../config/Label';
import colors from '../../../../config/Colors';
import {CheckBox} from '@rneui/themed';
import SingleSelector from '../../../../components/singleSelector/SingleSelector';
import {breakDuration} from '../../../../constants/constant';
import DateTimeInput from '../../../../components/dateTimeInput/DateTimeInput';

const ShiftDetail = () => {
  const [isFrontOfHouse, setIsFrontOfHouse] = useState(false);
  const [selectedIndex, setIndex] = useState(0);
  const [selectedUniform, setSelectedUniform] = useState(null);
  const [selectedImage, setSelectedImage] = useState(null);

  const uniforms = [
    images.chefDress1,
    images.chefDress2,
    images.chefDress3,
    images.chefDress4,
  ];

  const dataField = {
    business: '',
    contactName: '',
    brandName: '',
    companyNumber: '',
    vatNumber: '',
    mobileNumber: '',
    address: '',
    city: '',
    postcode: '',
    description: '',
  };

  const requestCameraPermission = async () => {
    if (Platform.OS === 'android') {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.CAMERA,
        {
          title: 'Camera Permission',
          message: 'App needs camera permission to take photos',
          buttonNeutral: 'Ask Me Later',
          buttonNegative: 'Cancel',
          buttonPositive: 'OK',
        },
      );
      return granted === PermissionsAndroid.RESULTS.GRANTED;
    }
    return true;
  };

  const openImagePicker = async () => {
    Alert.alert('Upload Photo', 'Choose an option', [
      {
        text: 'Take Photo',
        onPress: async () => {
          const hasPermission = await requestCameraPermission();
          if (!hasPermission) return;

          launchCamera({mediaType: 'photo'}, response => {
            if (response.didCancel) {
              console.log('User cancelled camera');
            } else if (response.errorCode) {
              console.log('Camera Error: ', response.errorMessage);
            } else if (response.assets && response.assets.length > 0) {
              const image = response.assets[0];
              console.log('Captured image: ', image.uri);
              setSelectedImage(image); // ✅ Save to state
              setSelectedUniform(null);
            }
          });
        },
      },
      {
        text: 'Upload Photo',
        onPress: () => {
          launchImageLibrary({mediaType: 'photo'}, response => {
            if (response.didCancel) {
              console.log('User cancelled image picker');
            } else if (response.errorCode) {
              console.log('Image Picker Error: ', response.errorMessage);
            } else if (response.assets && response.assets.length > 0) {
              const image = response.assets[0];
              console.log('Selected image: ', image.uri);
              setSelectedImage(image); // ✅ Save to state
              setSelectedUniform(null);
            }
          });
        },
      },
      {
        text: 'Cancel',
        style: 'cancel',
      },
    ]);
  };

  const validationSchema = Yup.object().shape({
    business: Yup.string().required(Label.businessNameReq),
    contactName: Yup.string().required(Label.contactNameReq),
    brandName: Yup.string().required(Label.brandNameReq),
    companyNumber: Yup.string().required(Label.companyDescriptionReq),
    vatNumber: Yup.string().required('Label.VATNameReq'),
    mobileNumber: Yup.string()
      .matches(/^\d{10}$/, Label.validNumberReq)
      .required(Label.mobileNumberReq),
    address: Yup.string().required(Label.addressReq),
    city: Yup.string().required(Label.cityReq),
    postcode: Yup.string().required(Label.postcodeReq),
    description: Yup.string().required(Label.companyDescriptionReq),
  });

  const handleDateChange = selectedDate => {
    console.log('Selected:', selectedDate);
  };

  return (
    <View style={styles.container}>
      <Header />
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.formContainer}>
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{paddingVertical: 25}}>
          <Text style={styles.text}>Job type</Text>
          <View style={styles.buttonRow}>
            <Button
              text="Temporary"
              additionalStyle={[
                styles.button,
                !isFrontOfHouse ? styles.activeButton : styles.inactiveButton,
              ]}
              additionalTestStyle={{
                color: isFrontOfHouse ? colors.accent : colors.secondary,
              }}
              onPress={() => setIsFrontOfHouse(false)}
            />
            <Button
              text="Permanent"
              additionalStyle={[
                styles.button,
                isFrontOfHouse ? styles.activeButton : styles.inactiveButton,
              ]}
              additionalTestStyle={{
                color: !isFrontOfHouse ? colors.accent : colors.secondary,
              }}
              onPress={() => setIsFrontOfHouse(true)}
            />
          </View>

          <Formik
            initialValues={dataField}
            validationSchema={validationSchema}
            onSubmit={values => console.log('Form data:', values)}>
            {({
              handleChange,
              handleBlur,
              handleSubmit,
              values,
              errors,
              touched,
            }) => (
              <View>
                <Input
                  placeholder="Shift Title"
                  value={values.business}
                  onChange={handleChange('business')}
                  error={touched.business && errors.business}
                />
                <Input
                  placeholder="How many workers"
                  value={values.contactName}
                  onChange={handleChange('contactName')}
                  error={touched.contactName && errors.contactName}
                />
                <Input
                  placeholder={Label.brandName}
                  value={values.brandName}
                  onChange={handleChange('brandName')}
                  error={touched.brandName && errors.brandName}
                />
                <Input
                  placeholder="Hourly rate"
                  value={values.companyNumber}
                  onChange={handleChange('companyNumber')}
                  error={touched.companyNumber && errors.companyNumber}
                />
                <Input
                  placeholder="About shift"
                  value={values.vatNumber}
                  onChange={handleChange('vatNumber')}
                  error={touched.vatNumber && errors.vatNumber}
                />
                <Input
                  placeholder="Shift benefits"
                  value={values.mobileNumber}
                  onChange={handleChange('mobileNumber')}
                  keyboardType="numeric"
                  error={touched.mobileNumber && errors.mobileNumber}
                />

                {/* Radio Button Section with RNEUI */}
                <Text style={styles.label}>
                  {Label.DoYouCurrentlyHaveAnyJobs}
                </Text>
                <View style={styles.checkContainer}>
                  <CheckBox
                    title={Label.Yes}
                    checked={selectedIndex === 0}
                    onPress={() => setIndex(0)}
                    checkedIcon="dot-circle-o"
                    uncheckedIcon="circle-o"
                    containerStyle={styles.checkBoxIcon}
                    textStyle={styles.checkBoxIconText}
                  />
                  <CheckBox
                    title={Label.No}
                    checked={selectedIndex === 1}
                    onPress={() => setIndex(1)}
                    checkedIcon="dot-circle-o"
                    uncheckedIcon="circle-o"
                    containerStyle={styles.checkBoxIcon}
                    textStyle={styles.checkBoxIcon}
                  />
                </View>

                <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                  <View style={styles.uniformRow}>
                    {uniforms.map((uniform, index) => (
                      <TouchableOpacity
                        key={index}
                        onPress={() => setSelectedUniform(index)}>
                        <Image
                          source={uniform}
                          style={[
                            styles.uniformImage,
                            selectedUniform === index && styles.uniformSelected,
                          ]}
                        />
                      </TouchableOpacity>
                    ))}
                  </View>
                </ScrollView>

                <View style={styles.uploadSection}>
                  <Text style={{color: colors.accent}}>
                    {Label.uploadCompanyLogo}
                  </Text>
                  <View style={styles.logoContainer}>
                    <View style={styles.logoBox}>
                      {selectedUniform ? (
                        <Image
                          source={uniforms[selectedUniform]}
                          style={styles.img}
                        />
                      ) : selectedImage ? (
                        <Image
                          source={selectedImage}
                          resizeMode="contain"
                          style={styles.img}
                        />
                      ) : (
                        <Image
                          source={images.uploadCompanyLogo}
                          resizeMode="contain"
                          style={styles.img}
                        />
                      )}
                    </View>
                    <TouchableOpacity
                      onPress={openImagePicker}
                      style={styles.cameraButton}>
                      <Image
                        source={images.cameraIcon}
                        style={styles.cameraIcon}
                      />
                    </TouchableOpacity>
                  </View>
                </View>

                <View style={styles.oneRowTwoFieldConatiner}>
                  <View style={styles.oneRowTwoField}>
                    <DateTimeInput
                      label="Start time"
                      onChange={handleDateChange}
                    />
                  </View>
                  <View style={styles.oneRowTwoField}>
                    <DateTimeInput
                      label="End time"
                      onChange={handleDateChange}
                    />
                  </View>
                </View>
                <SingleSelector
                  placeholder="Break duration"
                  data={breakDuration}
                />

                {/* Radio Button Section with RNEUI */}
                <Text style={styles.label}>This is a paid break?</Text>
                <View style={styles.checkContainer}>
                  <CheckBox
                    title={Label.Yes}
                    checked={selectedIndex === 0}
                    onPress={() => setIndex(0)}
                    checkedIcon="dot-circle-o"
                    uncheckedIcon="circle-o"
                    containerStyle={styles.checkBoxIcon}
                    textStyle={styles.checkBoxIconText}
                  />
                  <CheckBox
                    title={Label.No}
                    checked={selectedIndex === 1}
                    onPress={() => setIndex(1)}
                    checkedIcon="dot-circle-o"
                    uncheckedIcon="circle-o"
                    containerStyle={styles.checkBoxIcon}
                    textStyle={styles.checkBoxIcon}
                  />
                </View>

                <Button
                  text="Submit rule"
                  onPress={() => {
                    handleSubmit();
                    navigate('TabStack', { screen: '' });
                  }}
                  additionalStyle={styles.btnMargin}
                />
              </View>
            )}
          </Formik>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
};

export default ShiftDetail;
