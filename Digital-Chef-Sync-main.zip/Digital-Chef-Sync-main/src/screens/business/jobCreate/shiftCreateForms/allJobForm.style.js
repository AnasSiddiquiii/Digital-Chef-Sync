// PostShiftStyles.js
import {StyleSheet} from 'react-native';

import colors from '../../../../config/Colors';

export const shiftDetail = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.secondary,
  },
  formContainer: {
    paddingHorizontal: 20,
    flex: 1,
  },
  error: {
    color: 'red',
  },
  oneRowTwoFieldConatiner: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingTop: 10,
  },
  oneRowTwoField: {
    width: '48%',
  },
  text: {
    paddingVertical: 5,
    color: colors.accentLight,
    fontSize: 15,
  },
  uploadSection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 15,
  },
  logoContainer: {
    position: 'relative',
    alignSelf: 'flex-end',
  },
  logoBox: {
    width: 120,
    height: 120,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 10,
    overflow: 'hidden',
  },
  img: {
    width: '100%',
    height: '100%',
  },
  cameraButton: {
    position: 'absolute',
    top: 40,
    left: -18,
    padding: 5,
    borderRadius: 20,
    backgroundColor: colors.bgAccent,
    borderWidth: 1,
  },
  cameraIcon: {
    width: 25,
    height: 25,
  },
  termsText: {
    paddingVertical: 15,
  },
  termsLink: {
    fontWeight: '900',
    textDecorationLine: 'underline',
  },
  btnMargin: {
    marginBottom: 15,
    marginTop: 10,
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingBottom: 10,
  },
  button: {
    width: '48%',
    borderWidth: 1,
  },
  activeButton: {
    backgroundColor: colors.bgPrimary,
    borderColor: 'transparent',
  },
  inactiveButton: {
    backgroundColor: colors.bgSecondary,
    borderColor: colors.bgAccent,
  },
  label: {
    paddingLeft: 5,
    paddingVertical: 10,
    color: colors.accent,
  },
  checkContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingBottom: 10,
  },
  checkBoxIcon: {
    backgroundColor: 'transparent',
    borderWidth: 0,
    padding: 0,
  },
  checkBoxIconText: {
    fontStyle: 16,
  },
  uniformRow: {
    flexDirection: 'row',
    gap: 20, // if using RN >= 0.71
    paddingVertical: 20,
  },
  uniformImage: {
    width: 100,
    height: 140,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  uniformSelected: {
    borderColor: colors.primary,
  },
});

export const selectRolesStyles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bgSecondary,
  },
  contentWrapper: {
    paddingHorizontal: 20,
    paddingTop: 20,
    flex: 1,
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingBottom: 10,
  },
  button: {
    width: '48%',
    borderWidth: 1,
  },
  activeButton: {
    backgroundColor: colors.bgPrimary,
    borderColor: 'transparent',
  },
  inactiveButton: {
    backgroundColor: colors.bgSecondary,
    borderColor: colors.bgAccent,
  },
  scrollContent: {
    paddingBottom: 25,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    marginVertical: 10,
    color: colors.accent,
  },
  continueButton: {
    marginTop: 10,
  },
});
