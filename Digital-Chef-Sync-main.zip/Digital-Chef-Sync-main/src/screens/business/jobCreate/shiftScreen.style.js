import {StyleSheet} from 'react-native';
import colors from '../../../config/Colors';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bgSecondary,
  },
  contentWrapper: {
    flex: 1,
    paddingHorizontal: 20,
  },
  tabContainer: {
    paddingTop: 10,
    paddingBottom: 30,
  },
  listContainer: {
    paddingBottom: 10,
  },
  tabButton: {
    marginRight: 10,
    backgroundColor: colors.bgSecondary,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: colors.bgPrimary,
    paddingHorizontal: 10,
    height: 35,
    paddingVertical: 6,
  },
  tabText: {
    color: colors.primary,
    fontSize: 15,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginVertical: 10,
  },
  image: {
    width: 60,
    height: 60,
  },
  buttonText: {
    fontSize: 13,
  },
  button: {
    width: '30%',
    minHeight: 40,
  },
  textNotFound: {
    textAlign: 'center',
    color: colors.primary,
    marginTop: 20,
  },
  activeTab: {
    backgroundColor: colors.bgPrimary,
    borderColor: colors.bgSecondary,
  },
  activeTabText: {
    color: colors.secondary,
  },
  emptyContainer: {
    flex: 1,
  },
  textNotFound: {
    textAlign: 'center',
    color: colors.primary,
    fontSize: 16,
  },
});
