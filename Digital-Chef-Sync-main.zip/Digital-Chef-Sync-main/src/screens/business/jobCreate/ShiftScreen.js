import {FlatList, View, Text, Image} from 'react-native';
import {useCallback, useMemo, useState} from 'react';

import {navigate} from '../../../navigation/NavigationService';
import ShiftCard from '../../../components/shiftCard/ShiftCard';
import {jobDataDemo} from '../../../constants/constant';
import Button from '../../../components/button/Button';
import {images} from '../../../config/Images';
import {styles} from './shiftScreen.style';
import Label from '../../../config/Label';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const tabItems = ['Active shifts', 'Pending shifts', 'Complete shifts'];

const ShiftsScreen = () => {
  const [activeTab, setActiveTab] = useState('Active shifts');

  const handleNavigate = screen => {
    navigate('AppStack', {screen: screen});
  };

  const renderItem = useCallback(
    ({item}) => <ShiftCard shiftData={item} />,
    [],
  );

  const keyExtractor = useCallback(
    item => item.id?.toString() || item.title,
    [],
  );

  const renderTabItem = useCallback(
    ({item}) => (
      <View style={[styles.tabButton, activeTab === item && styles.activeTab]}>
        <Text
          style={[styles.tabText, activeTab === item && styles.activeTabText]}
          onPress={() => setActiveTab(item)}>
          {item}
        </Text>
      </View>
    ),
    [activeTab],
  );

  const filteredJobs = useMemo(() => {
    if (activeTab === 'Active shifts') {
      return jobDataDemo;
    } else if (activeTab === 'Pending shifts') {
      return [];
    } else if (activeTab === 'Complete shifts') {
      return [];
    }
    return [];
  }, [activeTab]);

  const {top} = useSafeAreaInsets();

  return (
    <View style={styles.container}>
      <View style={[styles.contentWrapper, {paddingTop: top}]}>
        <View style={styles.headerRow}>
          <Image source={images.splashImg} style={styles.image} />
          <Button
            text="Create shift"
            additionalTestStyle={styles.buttonText}
            additionalStyle={styles.button}
            onPress={() => handleNavigate('SelectRole')}
          />
        </View>

        <FlatList
          data={tabItems}
          horizontal
          showsHorizontalScrollIndicator={false}
          keyExtractor={item => item}
          renderItem={renderTabItem}
          contentContainerStyle={styles.tabContainer}
        />

        {filteredJobs.length > 0 ? (
          <FlatList
            data={jobDataDemo}
            keyExtractor={keyExtractor}
            renderItem={renderItem}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.listContainer}
          />
        ) : (
          <View style={styles.emptyContainer}>
            <Text style={styles.textNotFound}>{Label.noActiveShiftFound}</Text>
          </View>
        )}
      </View>
    </View>
  );
};

export default ShiftsScreen;
