import React, {useEffect, useState} from 'react';
import {View, FlatList, Text, TouchableOpacity, StyleSheet} from 'react-native';
import {styles} from './MessageListScreen.style';
import {navigate} from '../../../navigation/NavigationService';
import {dummyChats} from '../../../constants/constant';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

export default function MessageListScreen() {
  const [chats, setChats] = useState([]);
  
  const {top} = useSafeAreaInsets()

  // Replace with your logged-in user ID
  const userId = 'user1';

  useEffect(() => {
    setChats(dummyChats);
  }, []);

  const openChat = otherUserId => {
    navigate('AppStack', {
      screen: 'MessageScreen',
      params: {senderId: userId, receiverId: otherUserId},
    });
  };

  const formatTime = timestamp => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'});
  };

  return (
    <View style={[styles.container, {paddingTop:top}]}>
      <Text style={styles.heading}>Messages</Text>
      <FlatList
        showsVerticalScrollIndicator={false}
        data={chats}
        keyExtractor={item => item._id}
        renderItem={({item}) => {
          const otherUser = item._id;
          const message = item.latestMessage;

          return (
            <TouchableOpacity
              onPress={() => openChat(otherUser)}
              style={styles.chatItem}>
              <View>
                <Text style={styles.userName}>{message.receiverId}</Text>
                <Text style={styles.messageText}>{message.text}</Text>
              </View>
              <Text style={styles.time}>{formatTime(message.timestamp)}</Text>
            </TouchableOpacity>
          );
        }}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
      />
    </View>
  );
}
