import { StyleSheet } from "react-native";
import colors from "../../../../config/Colors";

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bgSecondary, // black
  },
  messageContainer: {
    maxWidth: '75%',
    padding: 12,
    borderRadius: 18,
    marginVertical: 4,
  },
  myMessage: {
    backgroundColor: colors.accentLight, 
    alignSelf: 'flex-end',
    borderBottomRightRadius: 0,
  },
  theirMessage: {
    backgroundColor: "#E8E8E8",
    alignSelf: 'flex-start',
    borderBottomLeftRadius: 0,
  },
  myText: {
    color: colors.secondary, // black text on gold
    fontSize: 16,
  },
  theirText: {
    color: colors.secondary, // white text on dark
    fontSize: 16,
  },
  timestamp: {
    color: 'black',
    fontSize: 11,
    marginTop: 4,
    textAlign: 'right',
  },
  inputContainer: {
    flexDirection: 'row',
    padding: 2,
    backgroundColor: '#1A1A1A',
    alignItems: 'center',
    borderTopWidth: 1,
    borderColor: '#333',
  },
  input: {
    width:"80%",
    marginRight:12
  },
  sendButton: {
    backgroundColor: colors.bgPrimary, // gold
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderRadius: 15,
  },
});