import { StyleSheet } from "react-native";
import colors from "../../../config/Colors";

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bgSecondary, // black background
  },
  chatItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
  },
  userName: {
    color: colors.primary,
    fontWeight: 'bold',
    fontSize: 16,
    marginBottom: 4,
  },
  messageText: {
    color: colors.accentLight,
    fontSize: 14,
  },
  time: {
    color: colors.accentLight,
    fontSize: 12,
  },
  separator: {
    height: 1,
    backgroundColor: '#222',
    marginVertical: 4,
  },
  heading: {
    color: colors.primary,
    fontSize: 25,
    textAlign: 'center',
    paddingVertical: 10,
    fontWeight:"700"
  },
});
