import { StyleSheet } from "react-native";
import colors from "../../config/Colors";

export const styles = StyleSheet.create({
  container: {
    flex:1,
    backgroundColor:colors.bgSecondary,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginVertical: 16,
    color:colors.primary,
    textAlign:"center"
  },
  card: {
    backgroundColor: colors.bgPrimary,
    padding: 16,
    borderRadius: 8,
    marginBottom: 12,
    elevation: 2,
    marginHorizontal:16
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 12,
  },
  nameRating: {
    flex: 1,
  },
  name: {
    fontWeight: 'bold',
    fontSize: 16,
  },
  rating: {
    flexDirection: 'row',
    marginTop: 4,
  },
  comment: {
    fontSize: 14,
    color: '#333',
  },
});
