import React from 'react';
import {View, Text, FlatList, Image} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import {styles} from './ReviewListScreen.style';
import {reviews} from '../../constants/constant';
import Header from '../../components/header/Header';
import {useSafeAreaInsets} from 'react-native-safe-area-context';

const renderStars = rating => {
  const full = Math.floor(rating);
  const half = rating % 1 >= 0.5;
  const stars = [];

  for (let i = 0; i < full; i++) {
    stars.push(
      <Icon key={`full-${i}`} name="star" size={16} color="#FF4B00" />,
    );
  }

  if (half) {
    stars.push(
      <Icon key="half" name="star-half-empty" size={16} color="#FF4B00" />,
    );
  }

  const total = half ? full + 1 : full;
  for (let i = total; i < 5; i++) {
    stars.push(
      <Icon key={`empty-${i}`} name="star-o" size={16} color="#FF4B00" />,
    );
  }

  return stars;
};

const ReviewCard = ({item}) => (
  <View style={styles.card}>
    <View style={styles.header}>
      {item.avatar && <Image source={item.avatar} style={styles.avatar} />}
      <View style={styles.nameRating}>
        <Text style={styles.name}>{item.name}</Text>
        <View style={styles.rating}>{renderStars(item.rating)}</View>
      </View>
    </View>
    <Text style={styles.comment}>{item.comment}</Text>
  </View>
);

const ReviewListScreen = () => {
  const {bottom} = useSafeAreaInsets();

  return (
    <View style={[styles.container, {paddingBottom: bottom}]}>
      <Header />
      <Text style={styles.headerTitle}>Reviews</Text>
      <FlatList
        data={reviews}
        keyExtractor={item => item.id}
        renderItem={({item}) => <ReviewCard item={item} />}
      />
    </View>
  );
};

export default ReviewListScreen;
