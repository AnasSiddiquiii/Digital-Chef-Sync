import { StyleSheet } from "react-native";
import colors from "../../config/Colors";

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bgSecondary,
  },
  subContainer: {
    flex: 1,
    padding: 24,
  },
  logo: {
    alignSelf: 'center',
    width: 80,
    height: 80,
    resizeMode: 'contain',
    marginVertical: 26,
  },
  inputContainer: {
    flexDirection: 'row',
    borderWidth: 1,
    borderColor: '#999',
    borderRadius: 10,
    alignItems: 'center',
    paddingHorizontal: 12,
    marginVertical: 8,
  },
  input: {
    flex: 1,
    height: 50,
  },
  updateButton: {
    backgroundColor: '#FF4B00',
    borderRadius: 10,
    paddingVertical: 14,
    marginTop: 24,
    alignItems: 'center',
  },
  updateText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});