import React, {useState} from 'react';
import {View, Text, TouchableOpacity, StyleSheet, Image} from 'react-native';
import {styles} from './ChangePassword.style';
import {images} from '../../config/Images';
import Header from '../../components/header/Header';
import Input from '../../components/input/Input';
import Button from '../../components/button/Button';

const ChangePasswordScreen = () => {
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const [showOld, setShowOld] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const handleUpdate = () => {
    if (newPassword !== confirmPassword) {
      alert('New passwords do not match!');
      return;
    }
    // Submit password update logic here
    alert('Password updated!');
  };

  return (
    <View style={styles.container}>
      <Header />
      <View style={styles.subContainer}>
        <Image source={images.splashImg} style={styles.logo} />

        {/* Old Password */}
        <Input
          placeholder="Old Password"
          value={oldPassword}
          onChange={setOldPassword}
          secureTextEntry={!showOld}
          rightIcon={showOld ? 'eye-slash' : 'eye'}
          pressOnRightIcon={() => setShowOld(!showOld)}
        />

        {/* New Password */}
        <Input
          placeholder="New Password"
          value={newPassword}
          onChange={setNewPassword}
          secureTextEntry={!showNew}
          rightIcon={showNew ? 'eye-slash' : 'eye'}
          pressOnRightIcon={() => setShowNew(!showNew)}
        />

        {/* Confirm Password */}
        <Input
          placeholder="Confirm Password"
          value={confirmPassword}
          onChange={setConfirmPassword}
          secureTextEntry={!showConfirm}
          rightIcon={showConfirm ? 'eye-slash' : 'eye'}
          pressOnRightIcon={() => setShowConfirm(!showConfirm)}
        />

        <Button
          onPress={handleUpdate}
          text="Update"
          additionalStyle={{marginTop: 20}}
        />
      </View>
    </View>
  );
};

export default ChangePasswordScreen;
