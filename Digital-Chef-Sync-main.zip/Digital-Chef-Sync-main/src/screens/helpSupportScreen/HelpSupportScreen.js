import React, {useState} from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  TextInput,
  StyleSheet,
  ScrollView,
} from 'react-native';
import {styles} from './HelpSupportScreen.style';
import {images} from '../../config/Images';
import Header from '../../components/header/Header';
import Button from '../../components/button/Button';

const HelpSupportScreen = () => {
  const [feedback, setFeedback] = useState('');

  return (
    <View style={styles.container}>
      <Header />
      <ScrollView contentContainerStyle={styles.subContainer}>
        <View style={styles.headerSection}>
          <Image
            source={images.splashImg} // Replace with actual image path
            style={styles.logo}
          />
          <Text style={styles.greeting}>
            Hello there, <Text style={styles.businessName}>Pizza hubb</Text>
          </Text>
          <Text style={styles.subtext}>
            Have a query? Please write to us and we will respond within 24 hours
          </Text>
        </View>

        <Button text="Call customer support" />

        <Text style={styles.orText}>OR</Text>

        <Text style={styles.feedbackLabel}>Feedback</Text>
        <TextInput
          style={styles.feedbackInput}
          placeholder="Type your message here"
          multiline
          value={feedback}
          onChangeText={setFeedback}
        />

        <Button text="Submit" />
      </ScrollView>
    </View>
  );
};

export default HelpSupportScreen;
