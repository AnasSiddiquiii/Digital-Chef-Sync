import { StyleSheet } from 'react-native';
import colors from '../../config/Colors';

export const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.bgSecondary,
    flexGrow: 1,
  },
  subContainer:{
    paddingHorizontal:20
  },
  headerSection: {
    alignItems: 'center',
    marginVertical: 30,
    paddingHorizontal:20
  },
  logo: {
    width: 80,
    height: 80,
    resizeMode: 'contain',
  },
  greeting: {
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
  },
  businessName: {
    fontWeight: 'bold',
  },
  subtext: {
    fontSize: 14,
    color: colors.accentLight,
    textAlign: 'center',
    marginTop: 5,
  },
  orText: {
    textAlign: 'center',
    color:colors.accentLight,
    marginVertical: 10,
  },
  feedbackLabel: {
    fontSize: 16,
    marginBottom: 5,
    color:colors.accentLight
  },
  feedbackInput: {
    borderWidth: 1,
    borderColor: colors.accentLight,
    borderRadius: 6,
    height: 120,
    padding: 10,
    textAlignVertical: 'top',
    marginBottom: 20,
  },
});
