import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  LayoutAnimation,
  Platform,
  UIManager,
} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import { styles } from './FAQs.style';
import { faqData } from '../../constants/constant';
import Header from '../../components/header/Header';

if (Platform.OS === 'android') {
  UIManager.setLayoutAnimationEnabledExperimental &&
    UIManager.setLayoutAnimationEnabledExperimental(true);
}


const FAQScreen = () => {
  const [expandedIndex, setExpandedIndex] = useState(null);

  const toggleExpand = (index) => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    setExpandedIndex(index === expandedIndex ? null : index);
  };

  return (
    <ScrollView style={styles.container}>
      <Header/>
      <Text style={styles.title}>FAQ's</Text>
      {faqData.map((item, index) => (
        <View key={index} style={styles.card}>
          <TouchableOpacity
            onPress={() => toggleExpand(index)}
            style={styles.questionRow}
            activeOpacity={0.7}
          >
            <Text style={styles.question}>{item.question}</Text>
            <Icon
              name={expandedIndex === index ? 'angle-up' : 'angle-down'}
              size={20}
              color="#FF4B00"
            />
          </TouchableOpacity>
          {expandedIndex === index && item.answer ? (
            <Text style={styles.answer}>{item.answer}</Text>
          ) : null}
        </View>
      ))}
    </ScrollView>
  );
};



export default FAQScreen;
