import { StyleSheet } from "react-native";
import colors from "../../config/Colors";

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bgSecondary,
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    marginVertical: 16,
    color: colors.primary,
    textAlign:"center"
  },
  card: {
    backgroundColor: '#FFEFE9',
    borderRadius: 8,
    marginBottom: 12,
    padding: 16,
    marginHorizontal:16
  },
  questionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  question: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FF4B00',
    flex: 1,
    paddingRight: 8,
  },
  answer: {
    marginTop: 12,
    fontSize: 14,
    color: '#333',
  },
});