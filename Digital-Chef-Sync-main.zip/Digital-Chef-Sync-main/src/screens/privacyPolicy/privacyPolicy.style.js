import {StyleSheet} from 'react-native';
import colors from '../../config/Colors';

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.bgSecondary,
    flex: 1,
  },
  contentContainer: {
    paddingHorizontal: 20,
    paddingVertical: 25,
  },
  sectionHeader: {
    fontSize: 16,
    fontWeight: 'bold',
    paddingTop: 10,
    color: colors.primary,
  },
  sectionContent: {
    textAlign: 'justify',
    paddingTop: 8,
    color: colors.accentLight,
  },
  linkText: {
    color: 'blue',
    textDecorationLine: 'underline',
  },
  rowContainer: {
    display: 'flex',
    flexDirection: 'row',
  },
});

export default styles;
