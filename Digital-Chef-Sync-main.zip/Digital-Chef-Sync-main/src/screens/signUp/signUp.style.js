import {StyleSheet} from 'react-native';

import colors from '../../config/Colors';

export default StyleSheet.create({
  mainContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  subContainer: {
    paddingHorizontal: 20,
    width: '100%',
  },
  errorText: {
    color: 'red',
    paddingnBottom: 10,
  },
  container: {
    paddingHorizontal: 20,
  },
  btnadditionalStyle: {width: '100%', marginTop: 20},
});
