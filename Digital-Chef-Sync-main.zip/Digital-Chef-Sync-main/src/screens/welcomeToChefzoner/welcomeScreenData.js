import Label from '../../config/Label';

export const buttonsData = [
  {
    text: Label.welcomeScreenButtonText2,
    screen: 'SignIn',
    icon: 'briefcase',
    path: 'business',
  },
  {
    text: Label.welcomeScreenButtonText1,
    screen: 'SignIn',
    icon: 'user',
    path: 'seeker',
  },
];
