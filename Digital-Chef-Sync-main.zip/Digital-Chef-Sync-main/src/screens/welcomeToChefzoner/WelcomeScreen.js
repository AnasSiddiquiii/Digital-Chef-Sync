import {View, Text, Image, StatusBar} from 'react-native';
import React from 'react';

import BgImageContainer from '../../components/bgImageContainer/bgImageContainer';
import {navigate} from '../../navigation/NavigationService';
import {buttonsData} from './welcomeScreenData';
import {images} from '../../config/Images';
import styles from './welcomeScreen.style';
import Label from '../../config/Label';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import Button from '../../components/button/Button';

const WelcomeScreen = () => {
  const {top} = useSafeAreaInsets();

  const handleNavigate = data => {
    navigate('SignIn', {path: data.path});
  };

  return (
    <BgImageContainer>
      {/* Set StatusBar color and style */}
      <StatusBar
        barStyle="light-content"
        backgroundColor="transparent"
        translucent
      />

      <View style={[styles.header, {paddingTop: top}]}>
        <Image source={images.splashImg} style={styles.logo} />
        <Text style={styles.welcomeText}>{Label.welcomeScreenHeader1}</Text>
        <Text style={styles.welcomeText}>{Label.welcomeScreenHeader2}</Text>
      </View>
      <View style={styles.buttonContainer}>
        {buttonsData.map((button, index) => (
          <Button
            key={index}
            additionalStyle={styles.additionalStyle}
            text={button.text}
            iconName={button.icon} // Pass icon name here
            onPress={() => handleNavigate(button)}
          />
        ))}
      </View>
    </BgImageContainer>
  );
};

export default WelcomeScreen;
