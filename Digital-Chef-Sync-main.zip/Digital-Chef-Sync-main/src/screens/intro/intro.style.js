import {StyleSheet} from 'react-native';
import {Dimensions} from 'react-native';

import colors from '../../config/Colors';
import fonts from '../../config/Fonts';

const {width} = Dimensions.get('window');

export default StyleSheet.create({
  mainContainer: {
    flex: 1,
    width,
  },
  subContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logo: {
    width: 250,
    height: 260,
  },
  text: {
    fontSize: 35,
    color: colors.accent,
    textAlign: 'center',
    paddingHorizontal: 20,
    fontWeight: '600',
    lineHeight: 50,
    paddingTop: 60,
  },
  text2: {
    fontSize: 20,
    color: colors.accent,
    textAlign: 'center',
    paddingBottom: 10,
    paddingHorizontal: 20,
    fontWeight: '400',
  },
});
