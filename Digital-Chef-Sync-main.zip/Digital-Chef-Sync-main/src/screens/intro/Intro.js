import React, {useCallback, useRef, useState} from 'react';
import {
  View,
  StatusBar,
  Image,
  Text,
  Pressable,
} from 'react-native';

import {navigate} from '../../navigation/NavigationService';
import Icon from 'react-native-vector-icons/FontAwesome';
import Styles from './intro.style';
import BgImageContainer from '../../components/bgImageContainer/bgImageContainer';
import {images} from '../../config/Images';
import Label from '../../config/Label';
import {useSafeAreaInsets} from 'react-native-safe-area-context';

const Intro = () => {
  const {bottom} = useSafeAreaInsets();

  return (
    <BgImageContainer>
      <StatusBar
        barStyle="light-content"
        backgroundColor="transparent"
        translucent
      />
      <View style={[Styles.mainContainer, {paddingBottom: bottom}]}>
        <View style={Styles.subContainer}>
          <Image source={images.introImg} style={Styles.logo} />
          <Text style={Styles.text}>{Label.intro}</Text>
          <Text style={Styles.text2}>{Label.findYourDreamJob}</Text>
        </View>
        <Pressable
        onPress={() => navigate("AuthStack",{screen:'WelcomeScreen'})}
          style={{
            flexDirection: 'row',
            justifyContent: 'flex-end',
            paddingBottom: 30,
            paddingRight: 10,
          }}>
          <Icon name="arrow-right" size={30} color="white" />
        </Pressable>
      </View>
    </BgImageContainer>
  );
};
export default Intro;
