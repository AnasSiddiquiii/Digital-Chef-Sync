import {StyleSheet} from 'react-native';

import colors from '../../config/Colors';

export default StyleSheet.create({
  errorText: {
    color: 'red',
    paddingnBottom: 10,
  },
  mainContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  subContainer: {
    paddingHorizontal: 20,
    width: '100%',
  },
  forgotPassword: {
    color: colors.primary,
    fontWeight: 'bold',
    paddingVertical: 20,
    textDecorationLine: 'underline',
    fontSize: 16,
  },
  additionalStyle: {marginTop: 20},
});
