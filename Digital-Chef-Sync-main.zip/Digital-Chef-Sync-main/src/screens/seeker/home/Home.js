import {FlatList, Text, TouchableOpacity, View, Image} from 'react-native';
import React, {useCallback, useState} from 'react';

import JobCard from '../../../components/jobCard/JobCard';
import {jobDataDemoSeeker} from '../../../constants/constant';
import Input from '../../../components/input/Input';
import Icon from 'react-native-vector-icons/FontAwesome';
import styles from './Home.style';
import Label from '../../../config/Label';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import BrowserJobModal from '../../../components/browserJobModal/BrowserJobModal';

const Home = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredJobs, setFilteredJobs] = useState(jobDataDemoSeeker);
  const [modalVisible, setModalVisible] = useState(false);
  const [filterValues, setFilterValues] = useState({
    shiftType: '',
    city: '',
    shiftRole: '',
    minRate: '',
    maxRate: '',
  });

  const {top} = useSafeAreaInsets();

  const handleSearch = query => {
    setSearchQuery(query);
    filterJobs({...filterValues, searchQuery: query});
  };

  const {bottom} = useSafeAreaInsets();

  const filterJobs = filters => {
    const {shiftType, city, shiftRole, minRate, maxRate, searchQuery} = filters;
    const filtered = jobDataDemoSeeker.filter(job => {
      return (
        (!searchQuery ||
          job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          job.subTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
          job.location.toLowerCase().includes(searchQuery.toLowerCase())) &&
        (!shiftType || job.type === shiftType) &&
        (!city || job.location.toLowerCase().includes(city.toLowerCase())) &&
        (!shiftRole ||
          job.title.toLowerCase().includes(shiftRole.toLowerCase())) &&
        (!minRate ||
          parseFloat(job.salary.replace('£', '')) >= parseFloat(minRate)) &&
        (!maxRate ||
          parseFloat(job.salary.replace('£', '')) <= parseFloat(maxRate))
      );
    });
    setFilteredJobs(filtered);
  };
  //
  // const pickDocument = async () => {
  //   const hasPermission = await useStoragePermission();
  //   if (!hasPermission) return;

  //   try {
  //     const res = await NativeDocumentPicker.pick({
  //       type: [DocumentPicker.types.allFiles],
  //     });

  //     console.log('Selected file:', res);
  //   } catch (err) {
  //     if (DocumentPicker.isCancel(err)) {
  //       console.log('User cancelled document picker');
  //     } else {
  //       console.error('Unknown error:', err);
  //     }
  //   }
  // };

  const renderJobCard = useCallback(({item}) => {
    return <JobCard jobItem={item} />;
  }, []);

  // Main return
  return (
    <View style={[styles.container, {paddingTop: top}]}>
      <View style={styles.searchContainer}>
        <View style={styles.searchInput}>
          <Input
            placeholder={Label.searchJob}
            value={searchQuery}
            onChange={handleSearch}
          />
        </View>
        <TouchableOpacity onPress={() => setModalVisible(true)}>
          <Icon name="filter" size={30} color="#D4AF37" />
        </TouchableOpacity>
      </View>

      {filteredJobs.length > 0 ? (
        <FlatList
          contentContainerStyle={{paddingHorizontal: 20, paddingBottom: bottom}}
          data={filteredJobs}
          keyExtractor={(_, index) => index.toString()}
          renderItem={renderJobCard}
        />
      ) : (
        <Text style={styles.textNotFound}>{Label.noActiveShiftFound}</Text>
      )}

      {/* Filter Modal */}
      <BrowserJobModal
        modalVisible={modalVisible}
        setModalVisible={setModalVisible}
        filterValues={filterValues}
        setFilterValues={setFilterValues}
        filterJobs={filterJobs}
      />
    </View>
  );
};

export default Home;
