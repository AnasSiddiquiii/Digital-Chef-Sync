import {View, Text, ScrollView} from 'react-native';
import {styles} from './walletScreen.style';
import InvoiceItem from '../../../components/invoiceItem/InvoiceItem';
import {invoices} from '../../../constants/constant';
import Header from '../../../components/header/Header';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import WalletItem from '../../../components/walletItem/WalletItem';

export default function WalletScreen() {
  const {bottom} = useSafeAreaInsets()
  return (
    <View style={styles.container}>
      <Header />
      <ScrollView style={styles.subContainer} contentContainerStyle={{paddingBottom:bottom}}>
        <Text style={styles.headerText}>Advance payment:</Text>
        <Text style={styles.valueText}>PKR 0</Text>

        <Text style={styles.headerText}>Total balance:</Text>
        <Text style={styles.totalText}>PKR 120.49</Text>

        {invoices.map(item => (
          <WalletItem key={item.id} item={item} />
        ))}
      </ScrollView>
    </View>
  );
}
