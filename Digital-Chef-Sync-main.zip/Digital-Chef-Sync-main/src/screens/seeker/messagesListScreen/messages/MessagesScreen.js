import React, {useState, useRef} from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import dayjs from 'dayjs';
import {styles} from './MessagesScreen.style';
import Input from '../../../../components/input/Input';
import {demoMessages} from '../../../../constants/constant';
import Header from '../../../../components/header/Header';

const currentUserId = 'user1';

export default function MessagesScreen() {
  const [messages, setMessages] = useState(demoMessages);
  const [inputText, setInputText] = useState('');
  const flatListRef = useRef();

  const sendMessage = () => {
    if (inputText.trim() === '') return;

    const newMessage = {
      id: Date.now().toString(),
      text: inputText,
      senderId: currentUserId,
      timestamp: Date.now(),
    };

    setMessages(prev => [...prev, newMessage]);
    setInputText('');
  };

  const renderMessage = ({item}) => {
    const isMe = item.senderId === currentUserId;
    return (
      <View
        style={[
          styles.messageContainer,
          isMe ? styles.myMessage : styles.theirMessage,
        ]}>
        <Text style={isMe ? styles.myText : styles.theirText}>{item.text}</Text>
        <Text style={styles.timestamp}>
          {dayjs(item.timestamp).format('h:mm A')}
        </Text>
      </View>
    );
  };

  return (
    <View style={{flex: 1}}>
      <Header />
      <KeyboardAvoidingView
        style={styles.container}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <FlatList
          showsVerticalScrollIndicator={false}
          ref={flatListRef}
          data={messages}
          renderItem={renderMessage}
          keyExtractor={item => item.id}
          contentContainerStyle={{padding: 10}}
        />

        <View style={styles.inputContainer}>
          <Input
            placeholder="Type a message"
            value={inputText}
            onChange={setInputText}
            additionalStyle={styles.input}
          />
          <TouchableOpacity onPress={sendMessage} style={styles.sendButton}>
            <Text style={{color: '#000', fontWeight: 'bold'}}>Send</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}
