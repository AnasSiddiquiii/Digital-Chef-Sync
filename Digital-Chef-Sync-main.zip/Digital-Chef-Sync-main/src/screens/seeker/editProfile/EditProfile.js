// ProfilePage.js
import React from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Image,
  StyleSheet,
  ScrollView,
} from 'react-native';
import {styles} from './EditProfile.style';
import {images} from '../../../config/Images';
import Header from '../../../components/header/Header';
import Input from '../../../components/input/Input';
import Button from '../../../components/button/Button';

const EditProfile = () => {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Header />
      <View style={{paddingHorizontal:16}}>
        <View style={styles.profileImageContainer}>
          <Image
            source={images.profileImage} // replace with your image
            style={styles.profileImage}
          />
          <TouchableOpacity style={styles.cameraIcon}>
            <Text style={styles.cameraIconText}>📷</Text>
          </TouchableOpacity>
        </View>

        <Text style={styles.title}>Anas Siddiqui</Text>
        <Input placeholder="Business name" />
        <Input placeholder="Brand name" />

        <View style={styles.row}>
          <Input placeholder="City" additionalStyle={styles.halfInput} />
          <Input placeholder="Postcode" additionalStyle={styles.halfInput} />
        </View>

        <Input placeholder="Address" />
        <Input placeholder="Contact number" />
        <Input placeholder="Company description" />

        <Button text="Update" additionalStyle={{marginTop:10}}/>
      </View>
    </ScrollView>
  );
};

export default EditProfile;
