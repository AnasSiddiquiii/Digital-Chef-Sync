import {StyleSheet} from 'react-native';
import colors from '../../../config/Colors';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.bgSecondary,
  },
  contentWrapper: {
    flex: 1,
    paddingHorizontal: 20,
  },
  tabContainer: {
    paddingTop: 10,
    paddingBottom: 30,
  },
  listContainer: {
    paddingBottom: 10,
  },
  tabButton: {
    marginRight: 10,
    borderRadius: 10,
    borderWidth: 1,
    paddingHorizontal: 24,
    height: 35,
    paddingVertical: 5,
    color: colors.primary,
    backgroundColor: colors.bgSecondary,
    borderColor: colors.bgPrimary,
  },
  tabText: {
    color: colors.primary,
    fontSize: 17,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginVertical: 10,
  },
  heading: {
    color: colors.primary,
    fontSize: 25,
    textAlign: 'center',
    paddingVertical: 10,
    fontWeight: '700',
  },
  activeTab: {
    backgroundColor: colors.bgPrimary,
    borderColor: colors.bgSecondary,
  },
  activeTabText: {
    color: colors.secondary,
  },
  emptyContainer: {
    flex: 1,
  },
  textNotFound: {
    textAlign: 'center',
    color: colors.primary,
    fontSize: 16,
  },
});
