import {FlatList, View, Text} from 'react-native';
import {useCallback, useMemo, useState} from 'react';
import {useSafeAreaInsets} from 'react-native-safe-area-context';

import ShiftCard from '../../../components/shiftCard/ShiftCard';
import {jobDataDemoSeeker} from '../../../constants/constant';
import {styles} from './ShiftsScreen.style';
import Label from '../../../config/Label';

const tabItems = ['Applied', 'Hired', 'Completed'];

const ShiftsScreen = () => {
  const {top} = useSafeAreaInsets();
  const [activeTab, setActiveTab] = useState('Applied');

  const renderItem = useCallback(
    ({item}) => <ShiftCard shiftData={item} />,
    [],
  );

  const keyExtractor = useCallback(
    item => item.id?.toString() || item.title,
    [],
  );

  const renderTabItem = useCallback(
    ({item}) => (
      <View style={[styles.tabButton, activeTab === item && styles.activeTab]}>
        <Text
          style={[styles.tabText, activeTab === item && styles.activeTabText]}
          onPress={() => setActiveTab(item)}>
          {item}
        </Text>
      </View>
    ),
    [activeTab],
  );

  const filteredJobs = useMemo(() => {
    if (activeTab === 'Applied') {
      return jobDataDemoSeeker
    }
    return [];
  }, [activeTab]);

  return (
    <View style={[styles.container, {paddingTop: top}]}>
      <View style={styles.contentWrapper}>
        <Text style={styles.heading}>Shifts</Text>

        <FlatList
          data={tabItems}
          horizontal
          showsHorizontalScrollIndicator={false}
          keyExtractor={item => item}
          renderItem={renderTabItem}
          contentContainerStyle={styles.tabContainer}
        />

        {filteredJobs.length > 0 ? (
          <FlatList
            data={jobDataDemoSeeker}
            keyExtractor={keyExtractor}
            renderItem={renderItem}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.listContainer}
          />
        ) : (
          <View style={styles.emptyContainer}>
            <Text style={styles.textNotFound}>{Label.noActiveShiftFound}</Text>
          </View>
        )}
      </View>
    </View>
  );
};

export default ShiftsScreen;
