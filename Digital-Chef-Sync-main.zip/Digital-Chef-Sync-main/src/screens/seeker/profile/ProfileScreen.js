import React from 'react';
import {View, Text, Image, TouchableOpacity, FlatList} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import {images} from '../../../config/Images';
import {styles} from './ProfileScreen.style';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import colors from '../../../config/Colors';
import {changeStack, navigate} from '../../../navigation/NavigationService';

const profileOptions = [
  {icon: 'credit-card', label: 'Wallet', route: 'WalletScreen'},
  {icon: 'lock', label: 'Change Password', route:'ChangePasswordScreen'},
  {icon: 'headphones', label: 'Help & support', route: 'HelpSupportScreen'},
  {icon: 'star-half-o', label: 'Reviews', route: 'ReviewListScreen'},
  {icon: 'question-circle', label: "FAQ's", route: 'FAQs'},
  {icon: 'sign-out', label: 'Log out', route: 'AuthStack'},
];

export default function ProfileScreen() {
  const {top} = useSafeAreaInsets();

  const handleNavigate = screen => {
    navigate('AppStack', {screen: screen});
  };

  return (
    <View style={[styles.container, {paddingTop: top}]}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.iconButton}>
          <Icon name="bars" size={20} color={colors.secondary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Profile</Text>
        <TouchableOpacity style={styles.iconButton} onPress={() => navigate("AppStack",{screen:"EditProfileSeeker"})}>
          <Icon name="pencil" size={20} color={colors.secondary} />
        </TouchableOpacity>
      </View>

      {/* Profile */}
      <View style={styles.profileSection}>
        <Image
          source={images.profileImage} // replace with your image
          style={styles.profileImage}
        />
        <Text style={styles.username}>Anas Siddiqui</Text>
        <View style={styles.ratingRow}>
          <Icon name="star" color="orange" size={18} />
          <Icon name="star" color="orange" size={18} />
          <Icon name="star" color="orange" size={18} />
          <Icon name="star" color="orange" size={18} />
          <Icon name="star-half-o" color="orange" size={18} />
          <Text style={styles.ratingText}>(9)</Text>
        </View>
      </View>

      {/* Menu */}
      <View style={styles.menuContainer}>
        <FlatList
          data={profileOptions}
          keyExtractor={item => item.label}
          renderItem={({item}) => (
            <TouchableOpacity
              style={styles.menuItem}
              onPress={() =>
                item.route == 'AuthStack'
                  ? changeStack(item.route)
                  : navigate('AppStack', {screen: item.route})
              }>
              <View style={styles.menuIconBox}>
                <Icon name={item.icon} size={20} color="black" />
              </View>
              <Text style={styles.menuLabel}>{item.label}</Text>
              <Icon
                name="angle-right"
                size={22}
                color={colors.primary}
                style={{marginLeft: 'auto'}}
              />
            </TouchableOpacity>
          )}
        />
      </View>
    </View>
  );
}
