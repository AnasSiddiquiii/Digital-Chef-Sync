import React, {useCallback} from 'react';
import {ScrollView, Text, View} from 'react-native';
import PlanCard from '../../../../components/planCard/PlanCard';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import {styles} from './Plans.style';
import {basicFeatures, premiumFeatures} from '../../../../constants/constant';
import {changeStack, navigate} from '../../../../navigation/NavigationService';

const Plans = () => {
  const handleNavigation = useCallback(
    () => changeStack('TabSeekerStack'),
    [],
  );
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.subContainer}>
        <Text style={styles.heading}>Unlock Powerful Features</Text>
        <PlanCard
          basicFeatures={basicFeatures}
          premiumFeatures={premiumFeatures}
          handleNavigation={handleNavigation}
        />
      </View>
    </ScrollView>
  );
};

export default Plans;
