export const Endpoints = {
  getTestingData: 'fact',
};
