const colors = {
  primary: '#D4AF37',
  primaryLight: '#FFD700',
  secondary: '#000000',
  accent: '#ffff',
  accentLight: '#808080',
  bgPrimary: '#D4AF37',
  bgSecondary: '#000000',
  bgAccent: '#ffff',
  btnPrimary: '#FF5400',
  btnSecondary: '#000000',
  btnAccent: '#ffff',
  inputplaceholder: '#888888',
};

export default colors;
